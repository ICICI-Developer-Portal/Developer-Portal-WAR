package com.icici.apigw.model;

import java.util.Date;

public class TestTxDetails {
	
	private String userId;
	private String apiName;
	private String apiId;
	private String requestPacket;
	private String responsePacket;
	private String testCaseId;
	private String testCaseStatus;
	private Date time;
	private String transactionId;
	
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getApiId() {
		return apiId;
	}
	public void setApiId(String apiId) {
		this.apiId = apiId;
	}
	public String getRequestPacket() {
		return requestPacket;
	}
	public void setRequestPacket(String requestPacket) {
		this.requestPacket = requestPacket;
	}
	public String getResponsePacket() {
		return responsePacket;
	}
	public void setResponsePacket(String responsePacket) {
		this.responsePacket = responsePacket;
	}
	public String getTestCaseId() {
		return testCaseId;
	}
	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}
	public String getTestCaseStatus() {
		return testCaseStatus;
	}
	public void setTestCaseStatus(String testCaseStatus) {
		this.testCaseStatus = testCaseStatus;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public String getApiName() {
		return apiName;
	}
	public void setApiName(String apiName) {
		this.apiName = apiName;
	}
	
	

}
