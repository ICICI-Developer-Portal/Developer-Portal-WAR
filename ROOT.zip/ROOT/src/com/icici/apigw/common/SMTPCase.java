package com.icici.apigw.common;

import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;

import com.icici.apigw.util.ConfigUtil;

public class SMTPCase {
	
	private static final String MAIL_HOST = ConfigUtil.get("mail.host");
	private static final int MAIL_PORT = Integer.valueOf(ConfigUtil.get("mail.port"));
	private static final String MAIL_FROM = ConfigUtil.get("mail.from");
	
    public boolean send(final String recipientEmail, final String subject, final String htmlMsg) {
    	boolean isSent = false;
    	if(recipientEmail.contains(",")) {
    		String[] recMailIds = recipientEmail.split(",");
    		for(int i=0;i<recMailIds.length;i++) {
    			HtmlEmail email = new HtmlEmail();
    			try {
    				email.setHostName(MAIL_HOST);
    				email.setSmtpPort(MAIL_PORT);
    				email.setFrom(MAIL_FROM);
    				email.setSubject(subject);
    				email.addTo(recMailIds[i].trim());
    				email.setHtmlMsg(htmlMsg);
    				email.send();
    				System.out.println("EMail Sent Successfully!!");
    	            isSent = true;
    			} catch (EmailException e) {
    				e.printStackTrace();
    			}
    		}
    	}
    	else{
	    	HtmlEmail email = new HtmlEmail();
			try {
				email.setHostName(MAIL_HOST);
				email.setSmtpPort(MAIL_PORT);
				email.setFrom(MAIL_FROM);
				email.setSubject(subject);
				email.addTo(recipientEmail);
				email.setHtmlMsg(htmlMsg);
				email.send();
				System.out.println("EMail Sent Successfully!!");
	            isSent = true;
			} catch (EmailException e) {
				e.printStackTrace();
			}
    	}
		return isSent;
    }

}