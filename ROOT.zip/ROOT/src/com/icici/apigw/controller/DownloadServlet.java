package com.icici.apigw.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

@WebServlet("/download")
public class DownloadServlet extends HttpServlet {
	private static final Logger LOGGER = LogManager.getLogger(DownloadServlet.class);
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	{
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response){

		StringBuffer jb = new StringBuffer();
		String line = null;
		try {
			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null)
				jb.append(line);
		} catch (Exception e) {
			writeLogs(e); 
		}
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").create();
		
		JsonObject model = gson.fromJson(jb.toString(), JsonObject.class);
		String fullFilepath = model.get("filePath").toString().trim().replace("\"", "");
		
		String filePath = fullFilepath;
        File downloadFile = new File(filePath);
        FileInputStream inStream = null;
		try {
			inStream = new FileInputStream(downloadFile);
		} catch (FileNotFoundException e) {
			writeLogs(e);
		}
         
        // if you want to use a relative path to context root:
        String relativePath = getServletContext().getRealPath("");
        System.out.println("relativePath = " + relativePath);
         
        // obtains ServletContext
        ServletContext context = getServletContext();
         
        // gets MIME type of the file
        String mimeType = context.getMimeType(filePath);
        if (mimeType == null) {        
            // set to binary type if MIME mapping not found
            mimeType = "application/octet-stream";
        }
        System.out.println("MIME type: " + mimeType);
         
        // modifies response
        response.setContentType(mimeType);
        response.setContentLength((int) downloadFile.length());
         
        // forces download
        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
        response.setHeader(headerKey, headerValue);
         
        // obtains response's output stream
        OutputStream outStream = null;
		try {
			outStream = response.getOutputStream();
		} catch (IOException e) {
			writeLogs(e);
		}
         
        byte[] buffer = new byte[4096];
        int bytesRead = -1;
         
        try {
			while ((bytesRead = inStream.read(buffer)) != -1) {
			    outStream.write(buffer, 0, bytesRead);
			}
		} catch (IOException e) {
			writeLogs(e);
		}
         
        try {
			inStream.close();
			outStream.close(); 
		} catch (IOException e) {
			writeLogs(e);
		}
        
	}
	public void writeLogs(Exception e) {
		StringWriter ex = new StringWriter();
		e.printStackTrace(new PrintWriter(ex));
		LOGGER.error(ex.toString());
	}

}
