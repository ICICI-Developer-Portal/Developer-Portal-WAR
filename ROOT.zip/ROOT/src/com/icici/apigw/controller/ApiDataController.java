package com.icici.apigw.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.icici.apigw.dao.ApiDataDao;
import com.icici.apigw.dao.ApiDataDaoImpl;
import com.icici.apigw.model.ApiData;
import com.icici.apigw.model.ApiPacket;
import com.icici.apigw.model.ApiRawData;
import com.icici.apigw.model.ErrorCode;
import com.icici.apigw.model.MerchantOnboardingDt;
import com.icici.apigw.model.PortalUserRegDt;
import com.icici.apigw.model.data_resp_domain_model;
import com.icici.apigw.model.data_resp_sub_api_model;
import com.icici.apigw.model.data_resp_sub_domain_model;

@Path("/doc")
public class ApiDataController {

    private ApiDataDao apiDataDao = new ApiDataDaoImpl();

    @javax.ws.rs.core.Context
    private HttpServletRequest sr;
    
    @POST
    @Path("/domain-and-apis")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response domain_and_apis(@FormParam("id") long id) {
        try {
        	Gson finalJson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).create();
        	List<ApiData> apiDataList = apiDataDao.getApiDetails();
            String finalApiListJson = finalJson.toJson(apiDataList);
            
            JSONArray jsonArray = new JSONArray(finalApiListJson);
            ArrayList<data_resp_domain_model> domain = new ArrayList<>();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String name = jsonObject.getString("ApiDomain");
                boolean isExists = false;
                for (int j = 0; j < domain.size(); j++) {
                    if (domain.get(j).domain.equalsIgnoreCase(name)) {
                        isExists = true;
                        break;
                    }
                }
                if (!isExists) {
                    data_resp_domain_model model = new data_resp_domain_model();
                    model.domain = name;
                    model.sub_domain = new ArrayList<>();
                    for (int k = 0; k < jsonArray.length(); k++) {
                        JSONObject jsonObjectD = jsonArray.getJSONObject(k);
                        if (jsonObjectD.getString("ApiDomain").equalsIgnoreCase(name)) {
                            String sub_name = jsonObjectD.getString("ApiSubDomain");
                            boolean isExistsD = false;
                            for (int l = 0; l < model.sub_domain.size(); l++) {
                                if (model.sub_domain.get(l).name.equalsIgnoreCase(sub_name)) {
                                    isExistsD = true;
                                    break;
                                }
                            }
                            if (!isExistsD) {
                                data_resp_sub_domain_model sub_domain_model = new data_resp_sub_domain_model();
                                sub_domain_model.name = sub_name;
                                sub_domain_model.api = new ArrayList<>();
                                for (int m = 0; m < jsonArray.length(); m++) {
                                    JSONObject jsonObjectA = jsonArray.getJSONObject(m);
                                    if (jsonObjectA.getString("ApiDomain").equalsIgnoreCase(name)) {
                                        if (jsonObjectA.getString("ApiSubDomain").equalsIgnoreCase(sub_name)) {
                                            String api_name = jsonObjectA.getString("ApiName");
                                            boolean isExistsA = false;
                                            for (int n = 0; n < sub_domain_model.api.size(); n++) {
                                                if (sub_domain_model.api.get(n).name.equalsIgnoreCase(api_name)) {
                                                    isExistsA = true;
                                                    break;
                                                }
                                            }
                                            if (!isExistsA) {
                                                data_resp_sub_api_model api_model = new data_resp_sub_api_model();
                                                api_model.ApiId = jsonObjectA.getString("ApiId");
                                                api_model.name = api_name;
                                                sub_domain_model.api.add(api_model);
                                            }
                                        }
                                    }
                                }
                                model.sub_domain.add(sub_domain_model);
                            }
                        }
                    }
                    domain.add(model);
                }
            }
            return Response.ok(domain).build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Response.serverError().build();
    }
    
    @GET
    @Path("/get-api-data")
    @Produces(MediaType.APPLICATION_JSON)
    public Response get_api_data() {
        try {
        	Gson finalJson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).create();
        	List<ApiData> apiDataList = apiDataDao.getApiDetails();
            return Response.ok(finalJson.toJson(apiDataList)).build();
        }catch (Exception e){
            e.printStackTrace();
        }
        return Response.serverError().build();
    }
    
    @POST
    @Path("/get-api-data-resp")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response get_api_data_resp(@FormParam("id") long id) {
        try {
        	Gson finalJson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).create();
        	List<ApiData> apiDataList = apiDataDao.getApiDetails();
            return Response.ok(finalJson.toJson(apiDataList)).build();
        }catch (Exception e){
            e.printStackTrace();
        }
        return Response.serverError().build();
    }

    @POST
    @Path("/load-api-data")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response load_api_data(@FormParam("id") long id) {
        try {
        	Gson finalJson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).create();
    		ApiRawData apiRawData = apiDataDao.getApiDetails(id+"");
            return Response.ok(finalJson.toJson(apiRawData)).build();
        }catch (Exception e){
            e.printStackTrace();
        }
        return Response.serverError().build();
    }

    @POST
    @Path("/load-error-codes")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response load_error_codes(@FormParam("id") long id) {
        try {
        	Gson finalJson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).create();
    		List<ErrorCode> errorCodes = apiDataDao.getErrorCodes();
            return Response.ok(finalJson.toJson(errorCodes)).build();
        }catch (Exception e){
            e.printStackTrace();
        }
        return Response.serverError().build();
    }

    @POST
    @Path("/load-api-packet")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_PLAIN})
    public Response load_api_packet(@FormParam("id") long id) {
        try {
        	final ApiPacket apiPacket = apiDataDao.loadApiPacket(id+"");
        	String resContentType = "text/plain";
    		if(apiPacket.getRequestType()==null || apiPacket.getRequestType().isEmpty()) {
    			resContentType = "text/plain";
    		} else if(apiPacket.getRequestType().equalsIgnoreCase("JSON")) {
    			resContentType = "application/json";
    		} else if(apiPacket.getRequestType().equalsIgnoreCase("XML")) {
    			resContentType = "application/xml";
    		} else {
    			resContentType = "text/plain";
    		}
            return Response.ok(apiPacket.getRequestPacket(), resContentType).build();
        }catch (Exception e){
            e.printStackTrace();
        }
        return Response.serverError().build();
    }
    
    @POST
    @Path("/save-merchant-details")
	public Response saveMerchantDetails(String rBody) {
    	try {
    		Gson gson=  new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").create();
    		MerchantOnboardingDt merDt = gson.fromJson(rBody, MerchantOnboardingDt.class);
    		boolean isSaved = apiDataDao.saveMerchantOnboardingData(merDt);
    		if(isSaved) {
    			return Response.ok("Ok").build();
    		}else {
    			return Response.serverError().build();
    		}
        }catch (Exception e){
            e.printStackTrace();
        }
        return Response.serverError().build();
	}
	
	@POST
    @Path("/save-portal-details")
	public Response savePortalDetails(String rBody) {
		try {
    		Gson gson=  new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").create();
    		PortalUserRegDt userReg = gson.fromJson(rBody, PortalUserRegDt.class);
    		boolean isSaved = apiDataDao.saveUserRegistrationData(userReg);
    		if(isSaved) {
    			return Response.ok("Ok").build();
    		}else {
    			return Response.serverError().build();
    		}
        }catch (Exception e){
            e.printStackTrace();
        }
        return Response.serverError().build();
	}
	
	@POST
    @Path("/fetch-jiraid")
	public Response fetchJiraIds(@FormParam("username") String username, @FormParam("env") String env) {
		try {
			if(env == null || env.isEmpty())
				env = "UAT";
    		Gson finalJson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).create();
    		List<MerchantOnboardingDt> merObList = apiDataDao.fetchJiraDetails(env, username, true);
            return Response.ok(finalJson.toJson(merObList)).build();
        }catch (Exception e){
            e.printStackTrace();
        }
        return Response.serverError().build();
	}

}