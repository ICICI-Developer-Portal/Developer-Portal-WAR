package com.icici.apigw.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import com.icici.apigw.db.RetriveDB;



@WebServlet("/GetTree")
public class DeveloperPoratlTree extends HttpServlet {
	
	private static final Logger logger=Logger.getLogger(DeveloperPoratlTree.class.getName());
	private static final long serialVersionUID = 1L;  
    public DeveloperPoratlTree() {
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json; charset=UTF-8");
		
    	String POSITIONID=request.getParameter("ID");
		Connection conn = null;
		String json;
		try {
			conn = new RetriveDB().getdbConnect();
			json=new JSONObject(new RetriveDB().dbOpr(conn,POSITIONID)).toString();
			logger.info("ID:: "+POSITIONID +"\r\n"+"FinalTree:: "+json);
			response.getWriter().append(json);
		} catch (SQLException | JSONException e) {
			response.getWriter().append(e.toString());
		}
		finally {
			try {
				if(conn.isClosed()) {
					logger.info("Connection closed already");
				}
				else {
					conn.close();
					logger.info("Connection closed");
				}
				
			} catch (SQLException e) {
				response.getWriter().append(e.toString());
			}
		}
		
	}

	

}
