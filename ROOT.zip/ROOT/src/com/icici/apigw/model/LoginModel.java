package com.icici.apigw.model;

public class LoginModel {
    public long id;
    public String email;
    public String domain;
    public String username;
    public int enabled;
	public String appathonusername;
	public String role;
	public String mobileNo;
	public String firstName;
	public String companyName;
	
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getEnabled() {
		return enabled;
	}
	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}
	public String getAppathonusername() {
		return appathonusername;
	}
	public void setAppathonusername(String appathonusername) {
		this.appathonusername = appathonusername;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "LoginModel [id=" + id + ", email=" + email + ", domain=" + domain + ", username=" + username
				+ ", enabled=" + enabled + ", appathonusername=" + appathonusername + ", role=" + role + ", mobileNo="
				+ mobileNo + ", firstName=" + firstName + ", companyName=" + companyName + "]";
	}
	
	
}
