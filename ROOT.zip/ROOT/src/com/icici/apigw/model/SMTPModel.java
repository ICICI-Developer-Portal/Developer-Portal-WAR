package com.icici.apigw.model;

public class SMTPModel {
    private int mail_id;
    private String sender_name;
    private String smtp;
    private String email_id;
    private String password;
    private int port_no;
    private int ssl_enabled;

    public int getMail_id() {
        return mail_id;
    }

    public void setMail_id(int mail_id) {
        this.mail_id = mail_id;
    }

    public String getSender_name() {
        return sender_name;
    }

    public void setSender_name(String sender_name) {
        this.sender_name = sender_name;
    }

    public String getSmtp() {
        return smtp;
    }

    public void setSmtp(String smtp) {
        this.smtp = smtp;
    }

    public String getEmail_id() {
        return email_id;
    }

    public void setEmail_id(String email_id) {
        this.email_id = email_id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getPort_no() {
        return port_no;
    }

    public void setPort_no(int port_no) {
        this.port_no = port_no;
    }

    public int getSsl_enabled() {
        return ssl_enabled;
    }

    public void setSsl_enabled(int ssl_enabled) {
        this.ssl_enabled = ssl_enabled;
    }
}
