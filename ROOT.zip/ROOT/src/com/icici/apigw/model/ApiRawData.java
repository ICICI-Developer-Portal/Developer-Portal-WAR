package com.icici.apigw.model;

import java.util.List;

/**
 * @author BAN187248
 *
 */
public class ApiRawData {

	private ApiData apiData;
	private List<RequestData> reqParam;
	private List<ResponseData> resParam;
	
	private List<ErrorCode> errorDetails;
	public List<ErrorCode> getErrorDetails() {
		return errorDetails;
	}
	public void setErrorDetails(List<ErrorCode> errorDetails) {
		this.errorDetails = errorDetails;
	}
	public ApiData getApiData() {
		return apiData;
	}
	public void setApiData(ApiData apiData) {
		this.apiData = apiData;
	}
	public List<RequestData> getReqParam() {
		return reqParam;
	}
	public void setReqParam(List<RequestData> reqParam) {
		this.reqParam = reqParam;
	}
	public List<ResponseData> getResParam() {
		return resParam;
	}
	public void setResParam(List<ResponseData> resParam) {
		this.resParam = resParam;
	}
	
	
	
}
