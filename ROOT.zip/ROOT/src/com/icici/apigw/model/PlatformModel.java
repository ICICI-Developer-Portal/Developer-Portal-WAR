package com.icici.apigw.model;

public class PlatformModel {
    public PlatformModel(){
        selected = false;
    }
    public String platform_id;
    public String platform_name;
    public boolean selected;
}
