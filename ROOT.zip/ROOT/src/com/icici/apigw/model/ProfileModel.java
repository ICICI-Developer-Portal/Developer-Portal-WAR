package com.icici.apigw.model;

public class ProfileModel {
    public String username;
    public String firstname;
    public String lastname;
    public String email;
    public String profile_photo;
    public String mobileno;
}
