package com.icici.apigw.model;


public class ErrorCode  {
	private String errId,errCode,errMsg,errDesc,errSystem;

	public String getErrId() {
		return errId;
	}

	public void setErrId(String errId) {
		this.errId = errId;
	}

	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public String getErrDesc() {
		return errDesc;
	}

	public void setErrDesc(String errDesc) {
		this.errDesc = errDesc;
	}

	public String getErrSystem() {
		return errSystem;
	}

	public void setErrSystem(String errSystem) {
		this.errSystem = errSystem;
	}
	
}
