package com.icici.apigw.model;

public class Appathon_Details_Model {
	String username;
	/*String password; 
	String usertype;*/
	String teamName;
	String teamSize;
	String teamCaptainName;
	String teamCaptainMobile;
	String teamCaptainEmail; 
	String teamMembersName;
	String teamMembersMobile;
	String teamMembersEmail;
	String location;
	String companyName;
	String ideaLink;
	String finalSubmissionLink;
	String status;
	String finalURL;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFinalURL() {
		return finalURL;
	}
	public void setFinalURL(String finalURL) {
		this.finalURL = finalURL;
	}
	/*public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}*/
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getTeamSize() {
		return teamSize;
	}
	public void setTeamSize(String teamSize) {
		this.teamSize = teamSize;
	}
	public String getTeamCaptainName() {
		return teamCaptainName;
	}
	public void setTeamCaptainName(String teamCaptainName) {
		this.teamCaptainName = teamCaptainName;
	}
	public String getTeamCaptainMobile() {
		return teamCaptainMobile;
	}
	public void setTeamCaptainMobile(String teamCaptainMobile) {
		this.teamCaptainMobile = teamCaptainMobile;
	}
	public String getTeamCaptainEmail() {
		return teamCaptainEmail;
	}
	public void setTeamCaptainEmail(String teamCaptainEmail) {
		this.teamCaptainEmail = teamCaptainEmail;
	}
	public String getTeamMembersName() {
		return teamMembersName;
	}
	public void setTeamMembersName(String teamMembersName) {
		this.teamMembersName = teamMembersName;
	}
	public String getTeamMembersMobile() {
		return teamMembersMobile;
	}
	public void setTeamMembersMobile(String teamMembersMobile) {
		this.teamMembersMobile = teamMembersMobile;
	}
	public String getTeamMembersEmail() {
		return teamMembersEmail;
	}
	public void setTeamMembersEmail(String teamMembersEmail) {
		this.teamMembersEmail = teamMembersEmail;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getIdeaLink() {
		return ideaLink;
	}
	public void setIdeaLink(String ideaLink) {
		this.ideaLink = ideaLink;
	}
	public String getFinalSubmissionLink() {
		return finalSubmissionLink;
	}
	public void setFinalSubmissionLink(String finalSubmissionLink) {
		this.finalSubmissionLink = finalSubmissionLink;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("username=");
		builder.append(username);
		builder.append(", teamName=");
		builder.append(teamName);
		builder.append(", teamSize=");
		builder.append(teamSize);
		builder.append(", teamCaptainName=");
		builder.append(teamCaptainName);
		builder.append(", teamCaptainMobile=");
		builder.append(teamCaptainMobile);
		builder.append(", teamCaptainEmail=");
		builder.append(teamCaptainEmail);
		builder.append(", teamMembersName=");
		builder.append(teamMembersName);
		builder.append(", teamMembersMobile=");
		builder.append(teamMembersMobile);
		builder.append(", teamMembersEmail=");
		builder.append(teamMembersEmail);
		builder.append(", location=");
		builder.append(location);
		builder.append(", companyName=");
		builder.append(companyName);
		builder.append(", ideaLink=");
		builder.append(ideaLink);
		builder.append(", finalSubmissionLink=");
		builder.append(finalSubmissionLink);
		builder.append(", status=");
		builder.append(status);
		builder.append(", finalURL=");
		builder.append(finalURL);
		return builder.toString();
	}
	
	
	
}
