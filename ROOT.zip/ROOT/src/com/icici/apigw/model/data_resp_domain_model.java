package com.icici.apigw.model;

import java.util.ArrayList;

public class data_resp_domain_model {
    public String domain;
    public ArrayList<data_resp_sub_domain_model> sub_domain;
}
