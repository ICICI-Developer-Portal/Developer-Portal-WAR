package com.icici.apigw.model;

public class Additional_details_model {
	String jiraID;
	String accountNumber;
	String cmsClientCode;
	String url;
	String ip;
	String port;
	String checksumRequired;
	String encryptionRequired;
	String certificate;
	String typeOfWebservice;
	String communincationMethod;
	String uat;
	String developement;
	String production;
	String modeOffered;
	String expeTransPerDay;
	String transLimitPerTran;
	String amount;
	String amountValidation;
	String urn1;
	String urn2;
	String disclaimerText;
	String emailRcptBill;
	String ifscCode;
	String virtualCode;
	String ipsRefundCode;
	String custCreditAccNumber;
	String headers;
	String reqResStructure;
	String testingId;
	
	public String getJiraID() {
		return jiraID;
	}
	public void setJiraID(String jiraID) {
		this.jiraID = jiraID;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getCmsClientCode() {
		return cmsClientCode;
	}
	public void setCmsClientCode(String cmsClientCode) {
		this.cmsClientCode = cmsClientCode;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getChecksumRequired() {
		return checksumRequired;
	}
	public void setChecksumRequired(String checksumRequired) {
		this.checksumRequired = checksumRequired;
	}
	public String getEncryptionRequired() {
		return encryptionRequired;
	}
	public void setEncryptionRequired(String encryptionRequired) {
		this.encryptionRequired = encryptionRequired;
	}
	public String getCertificate() {
		return certificate;
	}
	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}
	public String getTypeOfWebservice() {
		return typeOfWebservice;
	}
	public void setTypeOfWebservice(String typeOfWebservice) {
		this.typeOfWebservice = typeOfWebservice;
	}
	public String getCommunincationMethod() {
		return communincationMethod;
	}
	public void setCommunincationMethod(String communincationMethod) {
		this.communincationMethod = communincationMethod;
	}
	public String getUat() {
		return uat;
	}
	public void setUat(String uat) {
		this.uat = uat;
	}
	public String getDevelopement() {
		return developement;
	}
	public void setDevelopement(String developement) {
		this.developement = developement;
	}
	public String getProduction() {
		return production;
	}
	public void setProduction(String production) {
		this.production = production;
	}
	public String getModeOffered() {
		return modeOffered;
	}
	public void setModeOffered(String modeOffered) {
		this.modeOffered = modeOffered;
	}
	public String getExpeTransPerDay() {
		return expeTransPerDay;
	}
	public void setExpeTransPerDay(String expeTransPerDay) {
		this.expeTransPerDay = expeTransPerDay;
	}
	public String getTransLimitPerTran() {
		return transLimitPerTran;
	}
	public void setTransLimitPerTran(String transLimitPerTran) {
		this.transLimitPerTran = transLimitPerTran;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getAmountValidation() {
		return amountValidation;
	}
	public void setAmountValidation(String amountValidation) {
		this.amountValidation = amountValidation;
	}
	public String getUrn1() {
		return urn1;
	}
	public void setUrn1(String urn1) {
		this.urn1 = urn1;
	}
	public String getUrn2() {
		return urn2;
	}
	public void setUrn2(String urn2) {
		this.urn2 = urn2;
	}
	public String getDisclaimerText() {
		return disclaimerText;
	}
	public void setDisclaimerText(String disclaimerText) {
		this.disclaimerText = disclaimerText;
	}
	public String getEmailRcptBill() {
		return emailRcptBill;
	}
	public void setEmailRcptBill(String emailRcptBill) {
		this.emailRcptBill = emailRcptBill;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getVirtualCode() {
		return virtualCode;
	}
	public void setVirtualCode(String virtualCode) {
		this.virtualCode = virtualCode;
	}
	public String getIpsRefundCode() {
		return ipsRefundCode;
	}
	public void setIpsRefundCode(String ipsRefundCode) {
		this.ipsRefundCode = ipsRefundCode;
	}
	public String getCustCreditAccNumber() {
		return custCreditAccNumber;
	}
	public void setCustCreditAccNumber(String custCreditAccNumber) {
		this.custCreditAccNumber = custCreditAccNumber;
	}
	public String getHeaders() {
		return headers;
	}
	public void setHeaders(String headers) {
		this.headers = headers;
	}
	public String getReqResStructure() {
		return reqResStructure;
	}
	public void setReqResStructure(String reqResStructure) {
		this.reqResStructure = reqResStructure;
	}
	public String getTestingId() {
		return testingId;
	}
	public void setTestingId(String testingId) {
		this.testingId = testingId;
	}
	
	@Override
	
	public String toString() {
		return "Additional_details_model [jiraID=" + jiraID + "]";
	}
}
