package com.icici.apigw.model;

public class AuthTypeModel {
    public AuthTypeModel() {
        selected = false;
    }

    public String id;
    public String name;
    public boolean selected;
}