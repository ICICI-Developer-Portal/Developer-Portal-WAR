package com.icici.apigw.model;


public class RequestData {

	private String reqId, reqName, reqType, reqDesc, reqMand;

	public String getReqId() {
		return reqId;
	}

	public void setReqId(String reqId) {
		this.reqId = reqId;
	}

	public String getReqName() {
		return reqName;
	}

	public void setReqName(String reqName) {
		this.reqName = reqName;
	}

	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public String getReqDesc() {
		return reqDesc;
	}

	public void setReqDesc(String reqDesc) {
		this.reqDesc = reqDesc;
	}

	public String getReqMand() {
		return reqMand;
	}

	public void setReqMand(String reqMand) {
		this.reqMand = reqMand;
	}

}
