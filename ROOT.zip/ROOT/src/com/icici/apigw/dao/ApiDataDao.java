package com.icici.apigw.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ws.rs.FormParam;

import org.json.JSONException;

import com.icici.apigw.model.Additional_details_model;
import com.icici.apigw.model.ApiData;
import com.icici.apigw.model.ApiPacket;
import com.icici.apigw.model.ApiRawData;
import com.icici.apigw.model.Appathon_Details_Model;
import com.icici.apigw.model.ErrorCode;
import com.icici.apigw.model.MenuDescriptionModel;
import com.icici.apigw.model.MenuTreeModel;
import com.icici.apigw.model.MerchantOnboardingDt;
import com.icici.apigw.model.PortalUserRegDt;

public interface ApiDataDao {

	List<ApiData> getApiDetails() throws SQLException;
	
	ApiRawData getApiDetails(String apiId) throws SQLException;
	
	ApiPacket loadApiPacket(String apiId) throws SQLException;
	
	List<ErrorCode> getErrorCodes() throws SQLException;
	
	boolean saveUserRegistrationData(PortalUserRegDt userReg) throws SQLException;
	
	boolean saveMerchantOnboardingData(MerchantOnboardingDt merDt) throws SQLException;

	List<MerchantOnboardingDt> fetchJiraDetails(String env, String username, boolean onlyCompleted) throws SQLException;
	
	List<MerchantOnboardingDt> fetchJiraDetailsV2(String username, boolean onlyCompleted) throws SQLException;
	
	List<MerchantOnboardingDt> fetchPendingJira(String domain, boolean onlyInComplete) throws SQLException;
	
	List<PortalUserRegDt> fetchPendingUserReg(String domain) throws SQLException;
	
	boolean updateUserRegWithApprover(String username, String approverUser) throws SQLException;
	
	String getDomainByUsername(String username) throws SQLException;
	
	boolean saveFeedback(String email, String feedback, String location, String Name, String Mobile, String Company, String Requirements) throws SQLException;
	
//	boolean updateJiraStatus(String username, String jiraId, String status) throws SQLException;
	
	boolean hasAdminAccess(String username) throws SQLException;
	String getCompanyName(String username) throws SQLException;
	
	boolean saveAdditionalDetails(Additional_details_model addotionalDetails) throws SQLException;
	
	boolean updateFilePathDetails(String filePath, String Certificate, String jiraID) throws SQLException;
	boolean updateFilePathDetailsAppathon(String filePath, String Certificate, String jiraID) throws SQLException;
	
	public List<Map<String, String>> getPortalTree(String id) throws IOException, SQLException, JSONException;
	public List<String> getUserDetails(String username) throws SQLException;
	public List<String> getCompanyInfo(String Name) throws IOException, SQLException;/***BAN187248***/
	public int isEmailDomainApproved(String domain) throws IOException, SQLException;
	public boolean saveAppathonDetails(String team_name, String team_captain_name, String team_captain_mobile, String team_captain_email, String team_size, String team_members_name, String team_members_mobile , String team_members_email, String location, String company_name, String username, String password, String usertype) throws SQLException;
	boolean updateAppathonDetails(String team_name, String team_captain_name, String team_captain_mobile,String team_captain_email, String team_size, String team_members_name, String team_members_mobile,String team_members_email, String location, String company_name, String username,String idea_link, String final_submission_link, String final_url)throws SQLException;
	public Appathon_Details_Model fetchAppathonDetails(String username) throws SQLException;
	public Appathon_Details_Model fetchDetailsByEmail(String email) throws SQLException;
	public Map<String, String> getAdditionalParameters(String id) throws IOException, SQLException, JSONException;
	public Map dbOpr(String id) throws IOException, SQLException, JSONException;
	public ArrayList<MenuTreeModel> getMenuDetails(String id) throws IOException, SQLException, JSONException;
	public ArrayList<MenuDescriptionModel> getMenuDescription(String id) throws IOException, SQLException, JSONException;
	public Map<String, ArrayList<String>> getPortalFAQ() throws IOException, SQLException, JSONException;
	}
