package com.icici.apigw.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.icici.apigw.common.PortalException;
import com.icici.apigw.controller.RestApi;
import com.icici.apigw.db.DbUtil;
import com.icici.apigw.model.LoginModel;
import com.icici.apigw.model.ResponseModel;
import com.icici.apigw.util.Utility;


public class CmsUsersDaoImpl implements CmsUsersDao {
	private static final Logger LOGGER = LogManager.getLogger(CmsUsersDaoImpl.class);

	Connection connection;
	
	private void getDBConnection() {
		try {
			connection = DbUtil.getLrsConnection();
		} catch (PortalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public LoginModel login(String username, String password) throws SQLException {
		getDBConnection();
		LoginModel loginModel = new LoginModel();
		PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement("select hmackey from cmsusers where username = ?");
            preparedStatement.setString(1, username);
            resultSet = preparedStatement.executeQuery();
            String hmacKey = null;
            if (resultSet.isBeforeFirst()) {
                while (resultSet.next()) {
                	hmacKey = resultSet.getString("hmackey");
                }
            }
            preparedStatement.close();
            preparedStatement = connection.prepareStatement("select * from cmsusers where (username = ? OR email = ?) and password = ? ");
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, username);
            if(hmacKey !=null && !hmacKey.isEmpty()) {
            	preparedStatement.setString(3, Utility.hmacSha512(password, hmacKey));
            }else {
            	preparedStatement.setString(3, Utility.sha1(password));
            }
            resultSet.close();
            resultSet = preparedStatement.executeQuery();
            if (resultSet.isBeforeFirst()) {
                while (resultSet.next()) {
                    /*loginModel = new LoginModel();*/
                    loginModel.email = resultSet.getString("email");
                    loginModel.domain = resultSet.getString("domain");
                    loginModel.username = resultSet.getString("username");
                    loginModel.id = resultSet.getLong("id");
                    loginModel.enabled = resultSet.getInt("enabled");
                    loginModel.mobileNo = resultSet.getString("mobileno");
                    loginModel.firstName = resultSet.getString("firstName");
                    loginModel.role="Regular";
                    break;
                }
            }
            try {
				LoginModel loginModel1 = new CmsUsersDaoImpl().loginApp(loginModel.username,loginModel.email);/*Performing Validation operation*/
				LOGGER.info("loginModel1 values with tostring :"+loginModel1.toString());
				loginModel.username=loginModel1.username;
				loginModel.appathonusername=loginModel1.appathonusername;
				loginModel.role=loginModel1.role;
			} catch (IOException e) {
				e.printStackTrace();
			}
		} finally {
            if (resultSet != null) {
                try {
                    if (!resultSet.isClosed()) {
                        resultSet.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                    DbUtil.close(connection);
            }
        }
		LOGGER.info("appathonusername:: "+loginModel.appathonusername+"**loginModel:: "+loginModel.role+"**username:: "+loginModel.username);
		return loginModel;
	}
	

	@Override
	public boolean isUsernameExist(String username) throws SQLException {
		getDBConnection();
		PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean isExists = false;
		try {
			preparedStatement = connection.prepareStatement("select username from cmsusers where username = ?");
            preparedStatement.setString(1, username);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.isBeforeFirst()) {
                while (resultSet.next()) {
                    isExists = true;
                    break;
                }
            }
		} finally {
            if (resultSet != null) {
                try {
                    if (!resultSet.isClosed()) {
                        resultSet.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                    DbUtil.close(connection);
            }
        }
		return isExists;
	}

    public boolean isEmailExist(String email) throws SQLException {
		getDBConnection();
		PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean isExists = false;
		try {
			preparedStatement = connection.prepareStatement("select email from cmsusers where email = ?");
            preparedStatement.setString(1, email);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.isBeforeFirst()) {
                while (resultSet.next()) {
                    isExists = true;
                    break;
                }
            }
		} finally {
            if (resultSet != null) {
                try {
                    if (!resultSet.isClosed()) {
                        resultSet.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                    DbUtil.close(connection);
            }
        }
		return isExists;
	}
    
    public long registration(String username, String password, String email, String firstname, String lastname, String ip, String mobileno, int AutoApprove) throws SQLException {
		getDBConnection();
		PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        long regNo = 0;
		try {
			preparedStatement = connection.prepareStatement("insert into cmsusers(username, domain, password, securepassword, email, firstName, lastName, middleInitials, euaAccepted, euaAcceptanceIP, usernameAlias, enabled, lastIP , mobileno )" +
                    " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, "LRSDEVELOPER");
            preparedStatement.setString(3, Utility.sha1(password));
            preparedStatement.setInt(4, 1);
            preparedStatement.setString(5, email);
            preparedStatement.setString(6, firstname);
            preparedStatement.setString(7, lastname);
            preparedStatement.setString(8, "");
            preparedStatement.setInt(9, 0);
            preparedStatement.setString(10, "");
            preparedStatement.setString(11, "");
            preparedStatement.setInt(12, AutoApprove);
            preparedStatement.setString(13, ip);
            preparedStatement.setString(14, mobileno);
	        
	        long i = 0;
	        preparedStatement.executeUpdate();
	        resultSet = preparedStatement.getGeneratedKeys();
	        if (resultSet.next()) {
	            i = resultSet.getLong(1);
	            regNo = i;
	        }
	        if (i > 0) {
	        	preparedStatement = connection.prepareStatement("INSERT INTO  cmsorganization (name, description, uuid) VALUES (?,?,NULL);", Statement.RETURN_GENERATED_KEYS);
                preparedStatement.setString(1, username + "_org");
                preparedStatement.setString(2, username + "_oragnaization");
                preparedStatement.executeUpdate();
                long orgId = 0;
                resultSet = preparedStatement.getGeneratedKeys();
                if (resultSet.next()) {
                    orgId = resultSet.getLong(1);
                }

                preparedStatement = connection.prepareStatement("INSERT INTO  cmsorganizationproperties (orgId,propertyValue,propertyName) VALUES (?,'//localhost:37080/CMS/Repository/lrs-2812','AccountPlan')");
                preparedStatement.setLong(1, orgId);
                preparedStatement.executeUpdate();

                preparedStatement = connection.prepareStatement("INSERT INTO  cmsorganizationusers (userid,orgId) VALUES (?,?)");
                preparedStatement.setLong(1, i);
                preparedStatement.setLong(2, orgId);
                preparedStatement.executeUpdate();


                DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm.ss");
                Date date = new Date();


                preparedStatement = connection.prepareStatement("INSERT INTO  cmsuserproperties (`uid`,`propertyValue`,`propertyName`) VALUES (?,'Pending','registrationStatus');");
                preparedStatement.setLong(1, i);
                preparedStatement.executeUpdate();

                preparedStatement = connection.prepareStatement("INSERT INTO  cmsuserproperties (`uid`,`propertyValue`,`propertyName`) VALUES (?,?,'pwLastSetDate');");
                preparedStatement.setLong(1, i);
                preparedStatement.setString(2, dateFormat.format(date).toString());
                preparedStatement.executeUpdate();

                preparedStatement = connection.prepareStatement("INSERT INTO  cmsuserproperties (`uid`,`propertyValue`,`propertyName`) VALUES (?,'true','UserProfileComplete');");
                preparedStatement.setLong(1, i);
                preparedStatement.executeUpdate();


                preparedStatement = connection.prepareStatement("INSERT INTO cmsuserroles VALUES (" + i + ",10)", Statement.RETURN_GENERATED_KEYS);
                preparedStatement.executeUpdate();
                preparedStatement = connection.prepareStatement("INSERT INTO cmsuserroles VALUES (" + i + ",12)", Statement.RETURN_GENERATED_KEYS);
                preparedStatement.executeUpdate();
	        }
		} finally {
            if (resultSet != null) {
                try {
                    if (!resultSet.isClosed()) {
                        resultSet.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                    DbUtil.close(connection);
            }
        }
		return regNo;
	}

	public boolean insertOrUpdateOtp(String mobileNo, String otp) throws SQLException {
		getDBConnection();
		PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean isInsertedOrUpdated = false;
		try {
			preparedStatement = connection.prepareStatement("select * from phone_verify where phone = ?");
            preparedStatement.setString(1, mobileNo);
            resultSet = preparedStatement.executeQuery();
            boolean isExists = false;
            if (resultSet.isBeforeFirst()) {
                while (resultSet.next()) {
                    isExists = true;
                    break;
                }
            }
            int i = 0;
            if (isExists) {
            	preparedStatement.close();
                preparedStatement = connection.prepareStatement("update phone_verify set otp = ? where phone = ?");
                preparedStatement.setString(1, otp);
                preparedStatement.setString(2, mobileNo);
                i = preparedStatement.executeUpdate();
            } else {
            	preparedStatement.close();
                preparedStatement = connection.prepareStatement("insert into phone_verify(phone, otp) values(?, ?)");
                preparedStatement.setString(1, mobileNo);
                preparedStatement.setString(2, otp);
                i = preparedStatement.executeUpdate();
            }
            if (i > 0) {
            	isInsertedOrUpdated = true;
            }
		} finally {
            if (resultSet != null) {
                try {
                    if (!resultSet.isClosed()) {
                        resultSet.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                    DbUtil.close(connection);
            }
        }
		return isInsertedOrUpdated;
	}
    
	public String verifyOtp(String mobileNo, String otp) throws SQLException {
		getDBConnection();
		PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String message = "";
		try {
			preparedStatement = connection.prepareStatement("select otp from phone_verify where phone = ?");
            preparedStatement.setString(1, mobileNo);
            resultSet = preparedStatement.executeQuery();
            String sentOtp = "";
            boolean isExists = false;
            if (resultSet.isBeforeFirst()) {
                while (resultSet.next()) {
                    isExists = true;
                    sentOtp = resultSet.getString("otp");
                    break;
                }
            }
            preparedStatement.close();
            if (isExists && sentOtp != null && sentOtp.length() > 0) {
                if (otp.equals(sentOtp)) {
                    preparedStatement = connection.prepareStatement("update phone_verify set otp = ? where phone = ?");
                    preparedStatement.setString(1, "");
                    preparedStatement.setString(2, mobileNo);
                    preparedStatement.executeUpdate();
                    message = "Mobile number verified successfully.";
                } else {
                	message = "Please enter correct otp code.";
                }
            } else {
            	message = "Please click on send otp to verify mobile number.";
            }
		} finally {
            if (resultSet != null) {
                try {
                    if (!resultSet.isClosed()) {
                        resultSet.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                    DbUtil.close(connection);
            }
        }
		return message;
	}
	
	public boolean isUserEnabled(long id, String password) throws SQLException {
		getDBConnection();
		boolean isExists = false;
		PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement("select hmackey from cmsusers where id = ?");
            preparedStatement.setLong(1, id);
            resultSet = preparedStatement.executeQuery();
            String hmacKey = null;
            if (resultSet.isBeforeFirst()) {
                while (resultSet.next()) {
                	hmacKey = resultSet.getString("hmackey");
                }
            }
            preparedStatement.close();
            preparedStatement = connection.prepareStatement("select enabled from cmsusers where id = ? AND password = ?");
            preparedStatement.setLong(1, id);
            if(hmacKey !=null && !hmacKey.isEmpty()) {
            	preparedStatement.setString(2, Utility.hmacSha512(password, hmacKey));
            }else {
            	preparedStatement.setString(2, Utility.sha1(password));
            }
            resultSet.close();
            resultSet = preparedStatement.executeQuery();
            if (resultSet.isBeforeFirst()) {
                while (resultSet.next()) {
                    isExists = true;
                    break;
                }
            }
		} finally {
            if (resultSet != null) {
                try {
                    if (!resultSet.isClosed()) {
                        resultSet.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                    DbUtil.close(connection);
            }
        }
		return isExists;
	}

	@Override
	public List<String> getRegPendingUsers() throws SQLException {
		getDBConnection();
		PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List<String> usernames = null;
		try {
			preparedStatement = connection.prepareStatement("select username from cmsusers where enabled=?");
			preparedStatement.setInt(1, 0);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.isBeforeFirst()) {
            	usernames = new ArrayList<>();
                while (resultSet.next()) {
                	usernames.add(resultSet.getString("username"));
                }
            }
		} finally {
            if (resultSet != null) {
                try {
                    if (!resultSet.isClosed()) {
                        resultSet.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                    DbUtil.close(connection);
            }
        }
		return usernames;
	}

	@Override
	public boolean enableUser(String username) throws SQLException {
		getDBConnection();
		PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean isEnabled = false;
        int i = 0;
		try {
			preparedStatement = connection.prepareStatement("update cmsusers set enabled = ? where username = ?");
            preparedStatement.setInt(1, 1);
            preparedStatement.setString(2, username);
            i = preparedStatement.executeUpdate();
            if (i > 0) {
            	isEnabled = true;
            }
		} finally {
            if (resultSet != null) {
                try {
                    if (!resultSet.isClosed()) {
                        resultSet.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                    DbUtil.close(connection);
            }
        }
		return isEnabled;
	}
	
	

	@Override
	public boolean rejectUser(String username) throws SQLException {
		getDBConnection();
		PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean isEnabled = true;
        boolean isRejected = false;
		try {
            preparedStatement = connection.prepareStatement("select id from cmsusers where username = ? and enabled=0");
            preparedStatement.setString(1, username);
            resultSet = preparedStatement.executeQuery();
            long uid = 0l;
            if (resultSet.isBeforeFirst()) {
                while (resultSet.next()) {
                	uid = resultSet.getLong("id");
                	isEnabled = false;
                }
            }
            if(!isEnabled) {
    	        preparedStatement = connection.prepareStatement("select orgId from cmsorganization where name = ?");
                preparedStatement.setString(1, username + "_org");
    	        preparedStatement.executeQuery();
    	        long orgId = 0l;
                if (resultSet.isBeforeFirst()) {
                    while (resultSet.next()) {
                    	orgId = resultSet.getLong("orgId");
                    }
                }
                
                preparedStatement = connection.prepareStatement("delete from cmsorganization where orgId = ?");
                preparedStatement.setLong(1, orgId);
    	        preparedStatement.executeUpdate();
    	        
    	        preparedStatement = connection.prepareStatement("delete from cmsorganizationproperties where orgid = ?");
                preparedStatement.setLong(1, orgId);
    	        preparedStatement.executeUpdate();
    	        
    	        preparedStatement = connection.prepareStatement("delete from cmsorganizationusers where orgId = ?");
                preparedStatement.setLong(1, orgId);
    	        preparedStatement.executeUpdate();
    	        
    	        preparedStatement = connection.prepareStatement("delete from cmsuserproperties where uid = ?");
                preparedStatement.setLong(1, uid);
    	        preparedStatement.executeUpdate();
    	        
    	        preparedStatement = connection.prepareStatement("delete from cmsuserroles where uid = ?");
                preparedStatement.setLong(1, uid);
    	        preparedStatement.executeUpdate();
    	        
    	        preparedStatement = connection.prepareStatement("delete from cmsusers where id = ?");
                preparedStatement.setLong(1, uid);
    	        preparedStatement.executeUpdate();
    	        
    	        isRejected= true;
            }
		} finally {
            if (resultSet != null) {
                try {
                    if (!resultSet.isClosed()) {
                        resultSet.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                    DbUtil.close(connection);
            }
        }
		return isRejected;
	}
	/******** Appathon validation model* @throws IOException ********/
	public LoginModel loginApp(String username, String email) throws SQLException, IOException {
		getdbConnect();
		LoginModel ValidateModel = new LoginModel();
		PreparedStatement preparedStatementQ1 = null;
		PreparedStatement preparedStatementQ2 = null;
		 ResultSet resultSet1 = null;
        ResultSet resultSet2 = null;
        String Role="";
        String Portalemail="";
        String AppathonUname="";
        String PortalUname="";
		try {
			Portalemail=email;
            preparedStatementQ1 = connection.prepareStatement("select * from APPATHON_DETAILS where (TEAM_CAPTAIN_EMAIL = ? )");
            preparedStatementQ1.setString(1,Portalemail);
            resultSet1 = preparedStatementQ1.executeQuery();
            if (resultSet1.isBeforeFirst()) {
                while (resultSet1.next()) {
                	AppathonUname=resultSet1.getString("username");
                	ValidateModel.appathonusername=AppathonUname;
                }
            }
            preparedStatementQ1.close();
            resultSet1.close();
            if(!AppathonUname.isEmpty() && AppathonUname.equals(username)) {
            	ValidateModel.role="Appathon";
            	ValidateModel.username=username;
            }
            else if(AppathonUname.isEmpty() ){
            	ValidateModel.role="Regular";
            	ValidateModel.username=username;
            }
           
            else {
            	ValidateModel.role="Both";
            	ValidateModel.username=username;
            }
             LOGGER.info("AppathonUname:: "+AppathonUname+"****"+"PortalUname:: "+ValidateModel.username+"**Role:: "+ValidateModel.role);
		} finally {
            if ((resultSet1 != null) ) {
                try {
                    if (!resultSet1.isClosed() && !resultSet1.isClosed()) {
                        resultSet1.close();
                        /*resultSet2.close();*/
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatementQ1 != null){
                try {
                	preparedStatementQ1.close();
                	/*preparedStatementQ2.close();*/
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
            	connection.close();
            	LOGGER.info("connection closed");
            }
        }
		LOGGER.info("**validation details :"+ValidateModel.toString());
		return ValidateModel;
	}
	public Connection getdbConnect() throws SQLException, IOException {
		InputStream read=getClass().getClassLoader().getResourceAsStream("validate_db.properties");
		Properties prop=new Properties();
		prop.load(read);
		try {
			Class.forName(prop.getProperty("driver"));
			connection = DriverManager.getConnection(prop.getProperty("url"), prop.getProperty("username"), prop.getProperty("password"));
			LOGGER.info("connection open");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} 
		return connection;
	}
	

}
