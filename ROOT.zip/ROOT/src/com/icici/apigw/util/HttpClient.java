package com.icici.apigw.util;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.GeneralSecurityException;
import java.security.cert.X509Certificate;
import java.util.UUID;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class HttpClient {

	public static String get(final String url, final String acceptHdr) {
		String output = "";
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(url);
			ClientResponse response = webResource.accept(acceptHdr).get(ClientResponse.class);
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
			}
			output = response.getEntity(String.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}

	public static String post(final String url, final String contypeHdr, final String input) {
		String output = "";
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(url);
			ClientResponse response = webResource.type(contypeHdr).post(ClientResponse.class, input);
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
			}
			output = response.getEntity(String.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}

	public static void main(String[] args) throws Exception {
//		final String output = get("http://172.16.13.223:8080/api/v1/jira/status?id=AG-551", "application/json");
//		System.out.println("Output from Server .... \n");
//		System.out.println(output);
		
		
		String id = UUID.randomUUID().toString();
		String mobileNo = "9982082289";
		
		JSONObject jsonObject = new JSONObject();
		
        jsonObject.put("tsxndetails2", "NA");
        jsonObject.put("tsxndetails1", "NA");
        jsonObject.put("Amount", "0.0");
        jsonObject.put("tsxn", "NA");
        jsonObject.put("appname", "Merchant_Name");
        jsonObject.put("deliverymode", "SMS");
        jsonObject.put("deliveryaddress", mobileNo);
        jsonObject.put("tsxnid1", id);
        
//		final String output = post("http://172.16.13.223:8080/api/v7/eotp?service=create", "application/json", jsonObject.toString());
//		System.out.println("Output from Server .... \n");
//		System.out.println(output);
		
		String response = "";
		
//		response = send_otp(mobileNo, id);
		
		String otp = "966501";
		id = "a320369a-d32a-4d3f-8b5c-8a33ebaa1a47";
		response = verify_otp(mobileNo, otp, id);
		String output = "{  \r\n" + 
				"   \"tsxn\":\"NA\",\r\n" + 
				"   \"appname\":\"Merchant_Name\",\r\n" + 
				"   \"respcode1\":\"000\",\r\n" + 
				"   \"deliveryaddress\":\"9982082289\",\r\n" + 
				"   \"tsxnid1\":\"6c6d5f28-70f0-45a5-805d-cb9a924d4c34\"\r\n" + 
				"}";
		try {
			JSONObject object1 = new JSONObject(output);
			System.out.println(object1.get("respcode"));
	        if (object1.getString("respcode").equalsIgnoreCase("000")) {
	        	System.out.println();
	        } else {
	            System.out.println("invalid OTP");
	        }
		} catch (Exception e) {
            e.printStackTrace();
        }
//		vkTest(null);
		
	}
	
    private static String send_otp(String mobile_no, String id) {
    	String response="";
        try {
        	disableCertificate();
            URL streamURL = new URL("https://172.16.13.223:8443/api/v7/eotp?service=create");
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("tsxndetails2", "NA");
            jsonObject.put("tsxndetails1", "NA");
            jsonObject.put("Amount", "0.0");
            jsonObject.put("tsxn", "NA");
            jsonObject.put("appname", "Merchant_Name");
            jsonObject.put("deliverymode", "SMS");
            jsonObject.put("deliveryaddress", mobile_no);
            jsonObject.put("tsxnid1", id);

            System.out.println("Request:- " + jsonObject.toString());
            HttpsURLConnection httpsPost = (HttpsURLConnection) streamURL.openConnection();
//            URLConnection con = streamURL.openConnection();
            httpsPost.setRequestMethod("POST");
            httpsPost.setUseCaches(false);
            httpsPost.addRequestProperty("Content-Type", "application/json");
            httpsPost.setDoOutput(true);
            httpsPost.setDoInput(true);
            httpsPost.setConnectTimeout(5 * 1000); //set timeout to 5
            httpsPost.setReadTimeout(10 * 1000);
            httpsPost.connect();

            OutputStream stream = httpsPost.getOutputStream();
            stream.write(jsonObject.toString().getBytes());
            stream.flush();

            int statusCode = httpsPost.getResponseCode();
            System.out.println("StatusCode:- " + statusCode);
            stream.close();

            if (statusCode == HttpURLConnection.HTTP_OK) {
                if (httpsPost.getInputStream() != null) {
                	response = Utility.convertStreamToString(httpsPost.getInputStream());
                	System.out.println("Response:- " + response);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    private static String verify_otp(String mobile_no, String otp_code, String txn_no) {
    	String response="";
        try {
            URL streamURL = new URL("https://172.16.13.223:8443/api/v7/eotp?service=verify");
            disableCertificate();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("tsxndetails2", "NA");
            jsonObject.put("tsxndetails1", "NA");
            jsonObject.put("amount", "0.0");
            jsonObject.put("tsxn", "NA");
            jsonObject.put("appname", "Merchant_Name");
            jsonObject.put("deliverymode", "SMS");
            jsonObject.put("deliveryaddress", mobile_no);
            jsonObject.put("tsxnid1", txn_no);
            jsonObject.put("OTP", otp_code);

            System.out.println("Request:- " + jsonObject.toString());
            HttpsURLConnection httpsPost = (HttpsURLConnection) streamURL.openConnection();
            httpsPost.setRequestMethod("POST");
            httpsPost.setUseCaches(false);
            httpsPost.addRequestProperty("Content-Type", "application/json");
            httpsPost.setDoOutput(true);
            httpsPost.setDoInput(true);
            httpsPost.setConnectTimeout(5 * 1000); //set timeout to 5
            httpsPost.setReadTimeout(10 * 1000);
            httpsPost.connect();

            OutputStream stream = httpsPost.getOutputStream();
            stream.write(jsonObject.toString().getBytes());
            stream.flush();

            int statusCode = httpsPost.getResponseCode();
            stream.close();

            System.out.println("StatusCode:- " + statusCode);
            
            if (statusCode == HttpURLConnection.HTTP_OK) {
                if (httpsPost.getInputStream() != null) {
                	response = Utility.convertStreamToString(httpsPost.getInputStream());
                	System.out.println("Response:- " + response);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }
	
    public static void disableCertificate() {
    	// Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }
        };
        
        try {
	     // Install the all-trusting trust manager
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (GeneralSecurityException e) {
		}
        // Create all-trusting host name verifier
        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };
        
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
    }
    
}
