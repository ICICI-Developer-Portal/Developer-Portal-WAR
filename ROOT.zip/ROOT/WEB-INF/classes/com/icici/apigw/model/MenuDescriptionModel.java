package com.icici.apigw.model;

import java.util.ArrayList;

public class MenuDescriptionModel {
	private String TAB_NAME;
	private String DESCRIPTION;
	private String ID;
	private String TYPE;
	private String IMAGE_URL;
	private String FILE_URL;
	public String getIMAGE_URL() {
		return IMAGE_URL;
	}
	public void setIMAGE_URL(String iMAGE_URL) {
		IMAGE_URL = iMAGE_URL;
	}
	public String getFILE_URL() {
		return FILE_URL;
	}
	public void setFILE_URL(String fILE_URL) {
		FILE_URL = fILE_URL;
	}
	private ArrayList<MenuDescriptionModel> tabs;
	public String getTAB_NAME() {
		return TAB_NAME;
	}
	public void setTAB_NAME(String tAB_NAME) {
		TAB_NAME = tAB_NAME;
	}
	public String getDESCRIPTION() {
		return DESCRIPTION;
	}
	public void setDESCRIPTION(String dESCRIPTION) {
		DESCRIPTION = dESCRIPTION;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getTYPE() {
		return TYPE;
	}
	public void setTYPE(String tYPE) {
		TYPE = tYPE;
	}
	public ArrayList<MenuDescriptionModel> getTabs() {
		return tabs;
	}
	public void setTabs(ArrayList<MenuDescriptionModel> tabs) {
		this.tabs = tabs;
	}
	
	
}
