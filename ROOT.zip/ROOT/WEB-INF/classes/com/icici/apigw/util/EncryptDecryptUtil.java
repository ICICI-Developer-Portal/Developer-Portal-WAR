package com.icici.apigw.util;

import java.security.Key;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class EncryptDecryptUtil {
	
	private static final String B64_KEY = "hqn8qEN7uIzGicxMr6+2vQ==";
	private static final String ALGO = "AES";
	
	public static void main(String[] args) {
//		System.out.println(decrypt("IG9x02dSkEtd7XeuZuvdGw=="));
//		System.out.println(decrypt("BpjFdOrB6+j2j4NjhUNllA=="));
//		System.out.println(decrypt("tAb/YnY1cmLboM40uwaVjQ=="));
//		IAIUATDB
//		IAIUATADMIN
//		iaiuatadmin_123
		String lrs = encrypt("lrs");
		System.out.println(lrs);
		System.out.println(decrypt("74uexyfMK6mCM7Pcn+570Q=="));
		System.out.println(encrypt("iaiuatadmin_123"));
		System.out.println("=============================");
		System.out.println(encrypt("APIGWUAT"));
		System.out.println("?uyG5%&GmKs#&Du# : "+encrypt("?uyG5%&GmKs#&Du#"));
		System.out.println(encrypt("APIGW_UAT_123"));
		System.out.println("=============================");
	}

	public static String encrypt(String string) {
		String encryptedStr = null;
		try {
			Key aesKey = new SecretKeySpec(Base64.getDecoder().decode(B64_KEY.getBytes()), ALGO);
			Cipher cipher = Cipher.getInstance(ALGO);
			cipher.init(Cipher.ENCRYPT_MODE, aesKey);
			byte[] encrypted = cipher.doFinal(string.getBytes());
			encryptedStr = new String(Base64.getEncoder().encode(encrypted));
		} catch (Exception e) {
			System.out.println("Exception Occurred : " + e.getMessage());
		}
		return encryptedStr;
	}

	public static String decrypt(String string) {
		String decryptedStr = null;
		try {
			Key aesKey = new SecretKeySpec(Base64.getDecoder().decode(B64_KEY.getBytes()), ALGO);
			Cipher cipher = Cipher.getInstance(ALGO);
			cipher.init(Cipher.DECRYPT_MODE, aesKey);
			decryptedStr = new String(cipher.doFinal(Base64.getDecoder().decode(string)));
		} catch (Exception e) {
			System.out.println("Exception Occurred : " + e.getMessage());
		}
		return decryptedStr;

	}

}
