package com.icici.apigw.model;

public class TestCaseDetails {

	private String testCaseId;
	private String testCaseName;
	private String apiId;
	private String requestPacket;
	private String responsePacket;
	private String testCaseStatus;
	
	public String getTestCaseId() {
		return testCaseId;
	}
	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}
	public String getTestCaseName() {
		return testCaseName;
	}
	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}
	public String getApiId() {
		return apiId;
	}
	public void setApiId(String apiId) {
		this.apiId = apiId;
	}
	public String getRequestPacket() {
		return requestPacket;
	}
	public void setRequestPacket(String requestPacket) {
		this.requestPacket = requestPacket;
	}
	public String getResponsePacket() {
		return responsePacket;
	}
	public void setResponsePacket(String responsePacket) {
		this.responsePacket = responsePacket;
	}
	public String getTestCaseStatus() {
		return testCaseStatus;
	}
	public void setTestCaseStatus(String testCaseStatus) {
		this.testCaseStatus = testCaseStatus;
	}
	
	
	
}
