package com.icici.apigw.db;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class DBConnUtil {
	private static DataSource dataSource;
	private static final String JNDI_LOOKUP_SERVICE = "java:/comp/env/jdbc/devportal";
	private static final Logger LOGGER = LogManager.getLogger(DBConnUtil.class);

	static {
		try {
			Context context = new InitialContext();
			Object lookup = context.lookup(JNDI_LOOKUP_SERVICE);
			if (lookup != null) {
				dataSource = (DataSource) lookup;
			} else {
				new RuntimeException("Datasource not found !!!");
			}
		} catch (NamingException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		}
	}

	public static DataSource getDataSoure() {
		return dataSource;
	}

	public static Connection getConnection() throws SQLException {
		return dataSource.getConnection();
	}

	public static void close(PreparedStatement preparedStatement, Connection connection) {
 		closePreparedStatement(preparedStatement);
		closeConnection(connection);
	}

	public static void close(ResultSet resultSet, PreparedStatement preparedStatement, Connection connection) {
		closeResultSet(resultSet);
		closePreparedStatement(preparedStatement);
		closeConnection(connection);
 	}
 
	public static void closeResultSet(ResultSet resultSet) {
		try {
			if (resultSet != null) {
				resultSet.close();
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		}
	}

	public static void closePreparedStatement(PreparedStatement preparedStatement) {
		try {
			if (preparedStatement != null) {
				preparedStatement.close();
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		}
 	}

	public static void closeConnection(Connection connection) {
		try {
			if (connection != null) {
 				connection.close();
 			}
		} catch (Exception e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		}
	}
}
