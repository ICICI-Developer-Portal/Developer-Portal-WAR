package com.icici.apigw.dao;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONException;

import com.icici.apigw.cache.CacheUtil;
import com.icici.apigw.common.PortalException;
import com.icici.apigw.db.DBConnUtil;
import com.icici.apigw.db.DbUtil;
import com.icici.apigw.model.Additional_details_model;
import com.icici.apigw.model.ApiData;
import com.icici.apigw.model.ApiPacket;
import com.icici.apigw.model.ApiRawData;
import com.icici.apigw.model.Appathon_Details_Model;
import com.icici.apigw.model.ErrorCode;
import com.icici.apigw.model.MenuDescriptionModel;
import com.icici.apigw.model.MenuTreeModel;
import com.icici.apigw.model.MerchantOnboardingDt;
import com.icici.apigw.model.PortalUserRegDt;
import com.icici.apigw.model.RequestData;
import com.icici.apigw.model.ResponseData;
import com.icici.apigw.util.ConfigUtil;
import com.icici.apigw.util.GwConstants;
import com.icici.apigw.util.HttpClient;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

public class ApiDataDaoImpl implements ApiDataDao {

	private static final Logger LOGGER = LogManager.getLogger(ApiDataDaoImpl.class);

	public static final String JIRA_STATUS_URL = ConfigUtil.get("service.jira.status.url");

	private static final String QUERY_GET_API_DATA_ALL = "select * from API_DETAIL";
	private static final String QUERY_GET_API_DATA = "select * from API_DETAIL where API_ID = ?";
	private static final String QUERY_GET_REQ_DATA = "select * from API_REQ_PARAMETER where API_ID = ? order by REQ_MAND desc,REQ_ID";
	private static final String QUERY_GET_RES_DATA = "select * from API_RES_PARAMETER where API_ID = ? order by RESP_ID";
	private static final String QUERY_LOAD_API_PKT = "select * from API_SAMPLE_PACKET where API_ID = ?";
	private static final String QUERY_ERROR_CODES = "select * from API_ERROR_CODE";
	private static final String QUERY_GET_JIRA_DTLS = "select DOMAIN,DOMAIN_API,MERCHANT_NAME,DESCCRIPTION,SPOC_EMAIL,SPOC_PHONE,REL_MANAGER,IP_LIST,CALLBACK_URL,JIRA_ID,JIRA_STATUS,ENV from MER_ONBOARDING_TBL where ENV= ? and USER_NAME = ? and JIRA_ID not in (select REF_JIRA_ID from MER_ONBOARDING_TBL where REF_JIRA_ID is not null)";
	private static final String QUERY_GET_JIRA_DTLS_V2 = "select DOMAIN,DOMAIN_API,MERCHANT_NAME,DESCCRIPTION,SPOC_EMAIL,SPOC_PHONE,REL_MANAGER,IP_LIST,CALLBACK_URL,JIRA_ID,JIRA_STATUS,ENV,REF_JIRA_ID, API_URL, CERTIFICATE from MER_ONBOARDING_TBL where USER_NAME = ?";
	private static final String QUERY_GET_JIRA_DTLS_V2_FOR_ADMIN = "select DOMAIN,DOMAIN_API,MERCHANT_NAME,DESCCRIPTION,SPOC_EMAIL,SPOC_PHONE,REL_MANAGER,IP_LIST,CALLBACK_URL,JIRA_ID,JIRA_STATUS,ENV,REF_JIRA_ID, API_URL, CERTIFICATE from MER_ONBOARDING_TBL";
	private static final String QUERY_GET_PENDING_JIRA = "select DOMAIN,DOMAIN_API,MERCHANT_NAME,DESCCRIPTION,SPOC_EMAIL,SPOC_PHONE,REL_MANAGER,IP_LIST,CALLBACK_URL,JIRA_ID,JIRA_STATUS,ENV,REF_JIRA_ID from MER_ONBOARDING_TBL where DOMAIN= ?";
	private static final String QUERY_GET_PENDING_JIRA_ALL = "select DOMAIN,DOMAIN_API,MERCHANT_NAME,DESCCRIPTION,SPOC_EMAIL,SPOC_PHONE,REL_MANAGER,IP_LIST,CALLBACK_URL,JIRA_ID,JIRA_STATUS,ENV,REF_JIRA_ID from MER_ONBOARDING_TBL";
	private static final String QUERY_GET_DOMAIN_BY_USER = "select DOMAIN_NM from PORTAL_USER_REG_TBL where USER_NAME= ?";
	private static final String QUERY_GET_ROLE_BY_USER = "select ROLE from PORTAL_USER_REG_TBL where USER_NAME= ?";
	private static final String QUERY_GET_COMPANY_NAME_BY_USER = "select COMPANY_NAME from PORTAL_USER_REG_TBL where USER_NAME= ?";
	private static final String QUERY_GET_USER_DTLS = "select USER_NAME,FIRST_NAME,LAST_NAME,EMAIL,COMPANY_NAME,CONTACT_NO,DOMAIN_NM from PORTAL_USER_REG_TBL where DOMAIN_NM= ?";
	private static final String STMT_UPDATE_USER_DTLS_WITH_APPROVER = "UPDATE PORTAL_USER_REG_TBL SET APPROVER_NAME=? WHERE USER_NAME=?";

	private static final String STMT_INSERT_MER_ONBOARDING_DT = "INSERT INTO MER_ONBOARDING_TBL(USER_NAME,ENV,MERCHANT_NAME,DESCCRIPTION,SPOC_EMAIL,SPOC_PHONE,REL_MANAGER,REQUEST_DT,DOMAIN,DOMAIN_API,IP_LIST,CALLBACK_URL,JIRA_ID,REF_JIRA_ID,JIRA_STATUS,WHIZIBLE_CR,NDA_SIGNED,NDA_SIGNED_DT) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	// private static final String STMT_INSERT_PORTAL_USER_REG = "INSERT INTO
	// PORTAL_USER_REG_TBL(USER_NAME,FIRST_NAME,LAST_NAME,EMAIL,COMPANY_NAME,CONTACT_NO,TNC_CONFIRMED,TNC_CONFIRMED_DT,DOMAIN_NM,APPROVER_NAME,APPROVER_EMAIL_ID,REQUEST_DT)
	// VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
	private static final String STMT_INSERT_PORTAL_USER_REG = "INSERT INTO PORTAL_USER_REG_TBL(USER_NAME,FIRST_NAME,LAST_NAME,EMAIL,COMPANY_NAME,CONTACT_NO,TNC_CONFIRMED,TNC_CONFIRMED_DT,DOMAIN_NM,APPROVER_NAME,APPROVER_EMAIL_ID,REQUEST_DT,CITY,RM ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	private static final String STMT_INSERT_FEEDBACK_DTLS = "INSERT INTO PRTL_FEEDBACK(EMAIL,FEEDBACK, LOCATION, NAME, MOBILE, COMPANY, REQUIREMENTS) VALUES(?,?,?,?,?,?,?)";
	private static final String STMT_UPDATE_JIRA_STATUS = "UPDATE MER_ONBOARDING_TBL SET JIRA_STATUS = ? where JIRA_ID = ?";

	private static final String CS_KEY_API_DTL = "API_DTL";
	private static final String CS_KEY_MENU_TREE_DTLS = "MENU_TREE_DTL";
	private static final String CS_KEY_API_DTL_BY_ID = "API_DTLS-";
	private static final String CS_KEY_API_PKT = "API_PKT-";
	private static final String CS_KEY_ERR_CD = "ERR_CD";
	private static final String CS_KEY_JIRA_DTL = "JIRA_DTL-";
	private static final String SUPER_ADMIN_DOMAIN = "ALL";
	private static final String STMT_INSERT_ADDITIONAL_DETAILS = "INSERT INTO ADDITIONAL_DETAILS_TBL(JIRA_ID, ACCOUNT_NUMBER, CMS_CLIENT_CODE, URL, IP, PORT, CHECKSUM_REQUIRED, ENCRYPTION_REQUIRED, CERTIFICATE, TYPE_OF_WEBSERVICES, COMMUNICATION_METHOD, UAT, DEVELOPMENT, PRODUCTION, MODE_OFFERED, EXP_TRANS_PER_DAY, TRANS_LIMIT_PER_TRANS, AMOUNT, AMOUNT_VALIDATION, URN1, URN2, DISCLAIMER_TEXT, EMAILID_RCPT_BILL, IFSC_CODE, VIRTUAL_CODE, IPS_REFUND_CODE, CUSTOMER_CREDIT_ACC_NUMBER, HEADERS, REQUEST_RESPONSE_STRUCTURE, TESTING_IDS) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	private static final String STMT_INSERT_JWT_TOKEN_DETAILS = "INSERT INTO JWT_TOKEN_DETAILS(USERNAME, JWT_TOKEN, CREATE_DATE_TIME) VALUES(?,?,?)";
	private static final String STMT_UPDATE_JWT_TOKEN_DETAILS = "update JWT_TOKEN_DETAILS SET JWT_TOKEN = ?, create_date_time = ? where USERNAME = ?";
	private static final String STMT_GET_JWT_TOKEN = "Select JWT_TOKEN from JWT_TOKEN_DETAILS where USERNAME = ?";
	private static final String STMT_UPDATE_FILE_PATH = "UPDATE MER_ONBOARDING_TBL SET API_URL = ?, CERTIFICATE = ? where JIRA_ID = ?";
	private static final String STMT_UPDATE_PDF_FILE_PATH = "UPDATE MER_ONBOARDING_TBL SET API_URL = ? where JIRA_ID = ?";
	private static final String STMT_UPDATE_FILE_PATH_APPATHON = "UPDATE APPATHON_DETAILS SET IDEA_LINK = ? where JIRA_ID = ?";
	private static final String STMT_SELECT_MENU = "SELECT ID,TAB_NAME, TYPE, DESCRIPTION, API_ID FROM PORTAL_MENU_TREE WHERE STATUS='active' AND ID = ? OR PARENT_ID = ? ORDER BY ID";
	private static final String STMT_INSERT_APPATHON_DETAILS = "INSERT INTO APPATHON_DETAILS(TEAM_NAME, TEAM_CAPTAIN_NAME, TEAM_CAPTAIN_MOBILE, TEAM_CAPTAIN_EMAIL, TEAM_SIZE, TEAM_MEMBERS_NAME, TEAM_MEMBERS_MOBILE, TEAM_MEMBERS_EMAIL, LOCATION, COMPANY_NAME, USERNAME, PASSWORD, USERTYPE) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
	private static final String QUERY_GET_APPATHON_DETAILS = "select USERNAME, STATUS, TEAM_NAME, TEAM_SIZE, TEAM_CAPTAIN_NAME, TEAM_CAPTAIN_MOBILE, TEAM_CAPTAIN_EMAIL, TEAM_MEMBERS_NAME, TEAM_MEMBERS_MOBILE, TEAM_MEMBERS_EMAIL, LOCATION, COMPANY_NAME, IDEA_LINK, FINAL_SUBMISSION_LINK, FINAL_URL from APPATHON_DETAILS where USERNAME = ?";

	private static final String STMT_UPDATE_APPATHON_DETAILS = "UPDATE APPATHON_DETAILS SET TEAM_NAME = ?, TEAM_CAPTAIN_NAME = ?, TEAM_CAPTAIN_MOBILE = ?,TEAM_CAPTAIN_EMAIL = ?, TEAM_SIZE = ?, TEAM_MEMBERS_NAME = ?, TEAM_MEMBERS_MOBILE = ?, TEAM_MEMBERS_EMAIL = ?, LOCATION = ?,COMPANY_NAME = ?,USERNAME = ?, IDEA_LINK = ?,FINAL_SUBMISSION_LINK = ?, FINAL_URL = ? where USERNAME = ?";
	private static final String STMT_ADDITIONAL_PARAMETERS = "SELECT API_ID, FIELD_NAMES, API_NAME FROM ADD_PARAMETERS_TABLE WHERE API_ID IN ";
	
	Connection connection;

	private void getDBConnection() {
		try {
			connection = DBConnUtil.getDataSoure().getConnection();
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
//			e.printStackTrace();
		}
//			connection = DbUtil.getDocConnection();
//			System.out.println("Creating DB Connection !!!");
//			try (Connection conn = DBConnUtil.getDataSoure().getConnection()){
//				if(conn !=null) {
//					System.out.println("DBConnection Created !!!");
//				}
//				else {
//					System.out.println("DBConnection not Created !!!");
//				}
//			}
//			catch (Exception e) {
//				new RuntimeException("Error in Creating Connection : "+e);
//			}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ApiData> getApiDetails() throws SQLException {
		List<ApiData> apiDataList = null;
		Cache cache = CacheUtil.getApiDtlsCache();
		if (cache.isKeyInCache(CS_KEY_API_DTL) && cache.get(CS_KEY_API_DTL) != null) {
			Element ele = cache.get(CS_KEY_API_DTL);
			apiDataList = (List<ApiData>) ele.getObjectValue();
			LOGGER.info("getApiDetails from Cache..");
		} else {
			LOGGER.info("getApiDetails from DB..");
			apiDataList = getApiDetailsPri();
			cache.put(new Element(CS_KEY_API_DTL, apiDataList));
		}
		return apiDataList;
	}

	private List<ApiData> getApiDetailsPri(){
		getDBConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<ApiData> apiDataList = null;
		try {
			preparedStatement = connection.prepareStatement(QUERY_GET_API_DATA_ALL);
			resultSet = preparedStatement.executeQuery();
			apiDataList = new ArrayList<>();
			while (resultSet.next()) {
				ApiData table1 = new ApiData();
				table1.setApiId(resultSet.getString(1));
				table1.setApiDomain(resultSet.getString(2));
				table1.setApiName(resultSet.getString(3));
				table1.setApiDesc(resultSet.getString(4));
				table1.setApiSubDomain(resultSet.getString(5));
				table1.setSandboxUrl(resultSet.getString(6));
				apiDataList.add(table1);
			}
		}
		catch(SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		}
		finally {
			if (resultSet != null) {
				try {
					if (!resultSet.isClosed()) {
						resultSet.close();
					}
				} catch (SQLException e) {
					StringWriter ex = new StringWriter();
					e.printStackTrace(new PrintWriter(ex));
					LOGGER.error(ex.toString());
				}
			}
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					LOGGER.error(e);
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return apiDataList;
	}

	@Override
	public ApiRawData getApiDetails(String apiId) throws SQLException {
		ApiRawData apiRawData = null;
		Cache cache = CacheUtil.getApiDtlsCache();
		final String cacheKey = CS_KEY_API_DTL_BY_ID + apiId;
		if (cache.isKeyInCache(cacheKey) && cache.get(cacheKey) != null) {
			Element ele = cache.get(cacheKey);
			apiRawData = (ApiRawData) ele.getObjectValue();
			LOGGER.info("getApiDetails by Id from Cache..");
		} else {
			LOGGER.info("getApiDetails by Id from DB..");
			apiRawData = getApiDetailsPri(apiId);
			cache.put(new Element(cacheKey, apiRawData));
		}
		return apiRawData;
	}

	private ApiRawData getApiDetailsPri(String apiId){
		getDBConnection();
		ApiRawData apiRawData = null;
		try {
			apiRawData = new ApiRawData();
			apiRawData.setApiData(fetchApiData(apiId));
			apiRawData.setReqParam(fetchRequestData(apiId));
			apiRawData.setResParam(fetchResponseData(apiId));
		} 
		catch(Exception e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		}
		finally {
			DbUtil.close(connection);
		}
		return apiRawData;
	}

	@Override
	public ApiPacket loadApiPacket(final String apiId){
		ApiPacket apiPacket = null;
		Cache cache = CacheUtil.getApiPktCache();
		final String cacheKey = CS_KEY_API_PKT + apiId;
		if (cache.isKeyInCache(cacheKey) && cache.get(cacheKey) != null) {
			Element ele = cache.get(cacheKey);
			apiPacket = (ApiPacket) ele.getObjectValue();
			LOGGER.info("loadApiPacket by Id from Cache..");
		} else {
			LOGGER.info("loadApiPacket by Id from DB..");
			try {
				apiPacket = loadApiPacketPri(apiId);
			} catch (Exception e) {
				StringWriter ex = new StringWriter();
				e.printStackTrace(new PrintWriter(ex));
				LOGGER.error(ex.toString());
			}
			cache.put(new Element(cacheKey, apiPacket));
		}
		return apiPacket;
	}

	private ApiPacket loadApiPacketPri(final String apiId){
		getDBConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ApiPacket apiPacket = null;
		try {
			preparedStatement = connection.prepareStatement(QUERY_LOAD_API_PKT);
			preparedStatement.setString(1, apiId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				apiPacket = new ApiPacket();
				apiPacket.setRequestPacket(resultSet.getString(3));
				apiPacket.setRequestType(resultSet.getString(4));
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (resultSet != null) {
				try {
					if (!resultSet.isClosed()) {
						resultSet.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return apiPacket;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ErrorCode> getErrorCodes(){
		List<ErrorCode> errorCodes = null;
		Cache cache = CacheUtil.getApiDtlsCache();
		if (cache.isKeyInCache(CS_KEY_ERR_CD) && cache.get(CS_KEY_ERR_CD) != null) {
			Element ele = cache.get(CS_KEY_ERR_CD);
			errorCodes = (List<ErrorCode>) ele.getObjectValue();
			LOGGER.info("getErrorCodes from Cache..");
		} else {
			LOGGER.info("getErrorCodes from DB..");
//			try {
				errorCodes = getErrorCodesPri();
//			} catch (SQLException e) {
//				LOGGER.error(e);
//			}
			cache.put(new Element(CS_KEY_ERR_CD, errorCodes));
		}
		return errorCodes;
	}

	private List<ErrorCode> getErrorCodesPri(){
		getDBConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<ErrorCode> errorCodes = null;
		try {
			preparedStatement = connection.prepareStatement(QUERY_ERROR_CODES);
			resultSet = preparedStatement.executeQuery();
			errorCodes = new ArrayList<>();
			while (resultSet.next()) {
				ErrorCode ec = new ErrorCode();
				ec.setErrId(resultSet.getString(1));
				ec.setErrCode(resultSet.getString(2));
				ec.setErrMsg(resultSet.getString(3));
				ec.setErrDesc(resultSet.getString(4));
				ec.setErrSystem(resultSet.getString(5));
				errorCodes.add(ec);
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (resultSet != null) {
				try {
					if (!resultSet.isClosed()) {
						resultSet.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return errorCodes;
	}

	private ApiData fetchApiData(String apiId){
		ApiData table1 = new ApiData();
		ResultSet rs = null;/* ResultSet is for retrieving data from DB */
		PreparedStatement pstmt = null;
		try {
			pstmt = connection
					.prepareStatement(QUERY_GET_API_DATA);
			pstmt.setString(1, apiId);
			
			rs = pstmt.executeQuery();
			while (rs.next()) {
				table1.setApiId(rs.getString(1));
				table1.setApiDomain(rs.getString(2));
				table1.setApiName(rs.getString(3));
				table1.setApiDesc(rs.getString(4));
				table1.setApiSubDomain(rs.getString(5));
				table1.setSandboxUrl(rs.getString(6));
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			try {
				rs.close();
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return table1;
	}

	private List<RequestData> fetchRequestData(String apiId){
		List<RequestData> requestDataList = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = connection.prepareStatement(QUERY_GET_REQ_DATA);
			pstmt.setString(1, apiId);
			rs = pstmt.executeQuery();
			requestDataList = new ArrayList<RequestData>();
			while (rs.next()) {
				RequestData t2 = new RequestData();
				t2.setReqId(rs.getString(1));
				t2.setReqName(rs.getString(3));
				t2.setReqType(rs.getString(4));
				t2.setReqDesc(rs.getString(5));
				t2.setReqMand(rs.getString(6));
				requestDataList.add(t2);
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			try {
				rs.close();
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return requestDataList;
	}

	private List<ResponseData> fetchResponseData(String apiId){
		List<ResponseData> responseDataList = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = connection.prepareStatement(QUERY_GET_RES_DATA);
			pstmt.setString(1, apiId);
			rs = pstmt.executeQuery();
			responseDataList = new ArrayList<>();
			while (rs.next()) {
				ResponseData t3 = new ResponseData();
				t3.setResId(rs.getString(1));
				t3.setResName(rs.getString(3));
				t3.setResDesc(rs.getString(4));
				t3.setResType(rs.getString(5));
				responseDataList.add(t3);
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			try {
				rs.close();
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return responseDataList;
	}

	@Override
	public boolean saveUserRegistrationData(PortalUserRegDt userReg){
		getDBConnection();
		PreparedStatement pst = null;
		boolean isSaved = false;
		try {
			pst = connection.prepareStatement(STMT_INSERT_PORTAL_USER_REG);
			pst.setString(1, userReg.getUserName());
			pst.setString(2, userReg.getFirstName());
			pst.setString(3, userReg.getLastName());
			pst.setString(4, userReg.getEmail());
			pst.setString(5, userReg.getCompanyName());
			pst.setString(6, userReg.getContactNo());
			pst.setString(7, userReg.getTncConfirmed());
			pst.setDate(8, userReg.getTncConfirmedDt());
			pst.setString(9, userReg.getDomainNm());
			pst.setString(10, userReg.getApproverName());
			pst.setString(11, userReg.getApproverEmailId());
			pst.setDate(12, userReg.getRequestDt());
			pst.setString(13, userReg.getCity());
			pst.setString(14, userReg.getRmName());
			int i = pst.executeUpdate();
			if (i != 0) {
				isSaved = true;
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return isSaved;
	}

	@Override
	public boolean saveMerchantOnboardingData(MerchantOnboardingDt merDt){
		getDBConnection();
		PreparedStatement pst = null;
		boolean isSaved = false;
		try {
			pst = connection.prepareStatement(STMT_INSERT_MER_ONBOARDING_DT);
			pst.setString(1, merDt.getUserName());
			pst.setString(2, merDt.getEnv());
			pst.setString(3, merDt.getMerchantName());
			pst.setString(4, merDt.getDescription());
			pst.setString(5, merDt.getSpocEmail());
			pst.setString(6, merDt.getSpocPhone());
			pst.setString(7, merDt.getRelManager());
			pst.setDate(8, merDt.getRequestDt());
			pst.setString(9, merDt.getDomain());
			pst.setString(10, merDt.getDomainApi());
			pst.setString(11, merDt.getIpList());
			pst.setString(12, merDt.getCallbackUrl());
			pst.setString(13, merDt.getJiraId());
			pst.setString(14, merDt.getRefJiraId());
			pst.setString(15, merDt.getJiraStatus());
			pst.setString(16, merDt.getWhizibleCr());
			pst.setString(17, merDt.getNdaSigned());
			pst.setDate(18, merDt.getNdaSignedDt());
			int i = pst.executeUpdate();
			if (i != 0) {
				isSaved = true;
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return isSaved;
	}

	public List<MerchantOnboardingDt> fetchJiraDetails(String env, String username, boolean onlyCompleted){
		getDBConnection();
		PreparedStatement pstmt = null;
		List<MerchantOnboardingDt> merList = null;
		ResultSet rs = null;
		try {
			pstmt = connection.prepareStatement(QUERY_GET_JIRA_DTLS);
			pstmt.setString(1, env);
			pstmt.setString(2, username);
			rs = pstmt.executeQuery();
			merList = new ArrayList<>();
			while (rs.next()) {
				MerchantOnboardingDt mer = new MerchantOnboardingDt();
				mer.setDomain(rs.getString(1));
				mer.setDomainApi(rs.getString(2));
				mer.setMerchantName(rs.getString(3));
				mer.setDescription(rs.getString(4));
				mer.setSpocEmail(rs.getString(5));
				mer.setSpocPhone(rs.getString(6));
				mer.setRelManager(rs.getString(7));
				mer.setIpList(rs.getString(8));
				mer.setCallbackUrl(rs.getString(9));
				mer.setJiraId(rs.getString(10));
				mer.setJiraStatus(rs.getString(11));
				mer.setEnv(rs.getString(12));
				try {
					final String jiraStatus = fetchJiraStatus(mer.getJiraId());
					if (!mer.getJiraStatus().equalsIgnoreCase(jiraStatus)) {
						mer.setJiraStatus(jiraStatus);
						updateJiraStatus(mer.getJiraId(), jiraStatus);
					}
				} catch (Exception ne) {
					ne.printStackTrace();
				}

				// To show only those list whose Jira Status is complete.
				if (onlyCompleted) {

					if (mer.getJiraStatus().equalsIgnoreCase(GwConstants.JIRA_STS_COMPLETE)) {
						merList.add(mer);
					}
				} else {
					merList.add(mer);
				}
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			try {
				rs.close();
				pstmt.close();
				DbUtil.close(connection);
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return merList;
	}

	public List<MerchantOnboardingDt> fetchJiraDetailsV2(String username, boolean onlyCompleted){
		getDBConnection();
		PreparedStatement pstmt = null;
		List<MerchantOnboardingDt> merList = null;
		ResultSet rs = null;
		try {
			if(!username.equals("admin")) {
				pstmt = connection.prepareStatement(QUERY_GET_JIRA_DTLS_V2);
				pstmt.setString(1, username);
				rs = pstmt.executeQuery();
				merList = new ArrayList<>();
				while (rs.next()) {
					MerchantOnboardingDt mer = new MerchantOnboardingDt();
					mer.setDomain(rs.getString(1));
					mer.setDomainApi(rs.getString(2));
					mer.setMerchantName(rs.getString(3));
					mer.setDescription(rs.getString(4));
					mer.setSpocEmail(rs.getString(5));
					mer.setSpocPhone(rs.getString(6));
					mer.setRelManager(rs.getString(7));
					mer.setIpList(rs.getString(8));
					mer.setCallbackUrl(rs.getString(9));
					mer.setJiraId(rs.getString(10));
					mer.setJiraStatus(rs.getString(11));
					mer.setEnv(rs.getString(12));
					mer.setRefJiraId(rs.getString(13));
					mer.setUrl(rs.getString(14));
					String certPath = null;
					if(rs.getString(15) == null) {
						certPath = "";
					}
					else {
						certPath = rs.getString(15);
					}
					mer.setCertificate(certPath);
					try {
						final String jiraStatus = fetchJiraStatus(mer.getJiraId());
						if (!mer.getJiraStatus().equalsIgnoreCase(jiraStatus)) {
							mer.setJiraStatus(jiraStatus);
							updateJiraStatus(mer.getJiraId(), jiraStatus);
						}
					} catch (Exception ne) {
						StringWriter ex = new StringWriter();
						ne.printStackTrace(new PrintWriter(ex));
						LOGGER.error(ex.toString());
					}
	
					// To show only those list whose Jira Status is complete.
					if (onlyCompleted) {
	
						if (mer.getJiraStatus().equalsIgnoreCase(GwConstants.JIRA_STS_COMPLETE)) {
							merList.add(mer);
						}
					} else {
						merList.add(mer);
					}
				}
			}
			else {
	
				pstmt = connection.prepareStatement(QUERY_GET_JIRA_DTLS_V2_FOR_ADMIN);
	//			pstmt.setString(1, username);
				rs = pstmt.executeQuery();
				merList = new ArrayList<>();
				while (rs.next()) {
					MerchantOnboardingDt mer = new MerchantOnboardingDt();
					mer.setDomain(rs.getString(1));
					mer.setDomainApi(rs.getString(2));
					mer.setMerchantName(rs.getString(3));
					mer.setDescription(rs.getString(4));
					mer.setSpocEmail(rs.getString(5));
					mer.setSpocPhone(rs.getString(6));
					mer.setRelManager(rs.getString(7));
					mer.setIpList(rs.getString(8));
					mer.setCallbackUrl(rs.getString(9));
					mer.setJiraId(rs.getString(10));
					mer.setJiraStatus(rs.getString(11));
					mer.setEnv(rs.getString(12));
					mer.setRefJiraId(rs.getString(13));
					mer.setUrl(rs.getString(14));
					String certPath = null;
					if(rs.getString(15) == null) {
						certPath = "";
					}
					else {
						certPath = rs.getString(15);
					}
					mer.setCertificate(certPath);
					try {
						final String jiraStatus = fetchJiraStatus(mer.getJiraId());
						if (!mer.getJiraStatus().equalsIgnoreCase(jiraStatus)) {
							mer.setJiraStatus(jiraStatus);
							updateJiraStatus(mer.getJiraId(), jiraStatus);
						}
					} catch (Exception ne) {
						ne.printStackTrace();
					}
	
					// To show only those list whose Jira Status is complete.
					if (onlyCompleted) {
	
						if (mer.getJiraStatus().equalsIgnoreCase(GwConstants.JIRA_STS_COMPLETE)) {
							merList.add(mer);
						}
					} else {
						merList.add(mer);
					}
				}
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			try {
				rs.close();
				pstmt.close();
				DbUtil.close(connection);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return merList;
	}

	@Override
	public boolean saveFeedback(String email, String feedback, String location, String Name, String Mobile, String Company, String Requirements){
		getDBConnection();
		PreparedStatement pst = null;
		boolean isSaved = false;
		try {
			pst = connection.prepareStatement(STMT_INSERT_FEEDBACK_DTLS);
			pst.setString(1, email);
			pst.setString(2, feedback);
			pst.setString(3, location);
			pst.setString(4, Name);
			pst.setString(5, Mobile);
			pst.setString(6, Company);
			pst.setString(7, Requirements);
			
			
			int i = pst.executeUpdate();
			if (i != 0) {
				isSaved = true;
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return isSaved;
	}

	private String fetchJiraStatus(String jiraId) {
		final String output = HttpClient.get(String.format("%s?id=%s", JIRA_STATUS_URL, jiraId), "application/json");
		Object document = Configuration.defaultConfiguration().jsonProvider().parse(output);
		String jiraStatus = JsonPath.read(document, "$.status");
		return jiraStatus;
	}

	private boolean updateJiraStatus(String jiraId, String status){
		getDBConnection();
		PreparedStatement pst = null;
		boolean isSaved = false;
		try {
			pst = connection.prepareStatement(STMT_UPDATE_JIRA_STATUS);
			pst.setString(1, status);
			pst.setString(2, jiraId);
			int i = pst.executeUpdate();
			if (i != 0) {
				isSaved = true;
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			/*BAN213975-START on 30-04-2020*/
			if (connection != null) {
				DbUtil.close(connection);
			}
			/*BAN213975-END on 30-04-2020*/
		}
		return isSaved;
	}

	@Override
	public List<MerchantOnboardingDt> fetchPendingJira(String domain, boolean onlyInComplete){
		getDBConnection();
		PreparedStatement pstmt = null;
		List<MerchantOnboardingDt> merList = null;
		ResultSet rs = null;
		try {
			if (domain.equalsIgnoreCase(SUPER_ADMIN_DOMAIN)) {
				pstmt = connection.prepareStatement(QUERY_GET_PENDING_JIRA_ALL);
			} else {
				pstmt = connection.prepareStatement(QUERY_GET_PENDING_JIRA);
				pstmt.setString(1, domain);
			}
			rs = pstmt.executeQuery();
			merList = new ArrayList<>();
			while (rs.next()) {
				MerchantOnboardingDt mer = new MerchantOnboardingDt();
				mer.setDomain(rs.getString(1));
				mer.setDomainApi(rs.getString(2));
				mer.setMerchantName(rs.getString(3));
				mer.setDescription(rs.getString(4));
				mer.setSpocEmail(rs.getString(5));
				mer.setSpocPhone(rs.getString(6));
				mer.setRelManager(rs.getString(7));
				mer.setIpList(rs.getString(8));
				mer.setCallbackUrl(rs.getString(9));
				mer.setJiraId(rs.getString(10));
				mer.setJiraStatus(rs.getString(11));
				mer.setEnv(rs.getString(12));
				mer.setRefJiraId(rs.getString(13));
				try {
					final String jiraStatus = fetchJiraStatus(mer.getJiraId());
					if (!mer.getJiraStatus().equalsIgnoreCase(jiraStatus)) {
						mer.setJiraStatus(jiraStatus);
						updateJiraStatus(mer.getJiraId(), jiraStatus);
					}
				} catch (Exception ne) {
					ne.printStackTrace();
				}

				// To show only those list whose Jira Status is incomplete.
				if (onlyInComplete) {
					if (!mer.getJiraStatus().equalsIgnoreCase(GwConstants.JIRA_STS_COMPLETE)) {
						merList.add(mer);
					}
				} else {
					merList.add(mer);
				}

			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			try {
				rs.close();
				pstmt.close();
				DbUtil.close(connection);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return merList;
	}

	@Override
	public String getDomainByUsername(String username){
		getDBConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String domain = "";
		try {
			pstmt = connection.prepareStatement(QUERY_GET_DOMAIN_BY_USER);
			pstmt.setString(1, username);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				domain = rs.getString(1);
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			try {
				rs.close();
				pstmt.close();
				DbUtil.close(connection);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return domain;
	}

	@Override
	public List<PortalUserRegDt> fetchPendingUserReg(String domain){
		getDBConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<PortalUserRegDt> userList = null;
		try {
			pstmt = connection.prepareStatement(QUERY_GET_USER_DTLS);
			pstmt.setString(1, domain);
			rs = pstmt.executeQuery();
			userList = new ArrayList<>();
			while (rs.next()) {
				PortalUserRegDt user = new PortalUserRegDt();
				user.setUserName(rs.getString(1));
				user.setFullName(rs.getString(2) + " " + rs.getString(3));
				user.setEmail(rs.getString(4));
				user.setCompanyName(rs.getString(5));
				user.setContactNo(rs.getString(6));
				user.setDomainNm(rs.getString(7));
				userList.add(user);
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			try {
				rs.close();
				pstmt.close();
				DbUtil.close(connection);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return userList;
	}

	@Override
	public boolean updateUserRegWithApprover(String username, String approverUser){
		getDBConnection();
		PreparedStatement pst = null;
		boolean isUpdated = false;
		try {
			pst = connection.prepareStatement(STMT_UPDATE_USER_DTLS_WITH_APPROVER);
			pst.setString(1, approverUser);
			pst.setString(2, username);
			int i = pst.executeUpdate();
			if (i != 0) {
				isUpdated = true;
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return isUpdated;
	}

	@Override
	public boolean hasAdminAccess(String username){
		getDBConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		boolean isAdmin = false;
		try {
			pstmt = connection.prepareStatement(QUERY_GET_ROLE_BY_USER);
			pstmt.setString(1, username);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				if (rs.getString(1).toUpperCase().contains("ADMIN")) {
					isAdmin = true;
				}
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			try {
				rs.close();
				pstmt.close();
				DbUtil.close(connection);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return isAdmin;
	}
	
	@Override
	public String getCompanyName(String username){
		getDBConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String companyName = "";
		try {
			pstmt = connection.prepareStatement(QUERY_GET_COMPANY_NAME_BY_USER);
			pstmt.setString(1, username);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				companyName = rs.getString(1);
			}
		} catch (Exception e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			try {
				rs.close();
				pstmt.close();
				DbUtil.close(connection);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return companyName;
	}

	public boolean saveAdditionalDetails(Additional_details_model addotionalDetails){

		getDBConnection();
		PreparedStatement pst = null;
		boolean isSaved = false;
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			byte[] data = md.digest(addotionalDetails.getCertificate().getBytes());
			String str = DatatypeConverter.printHexBinary(data);
			pst = connection.prepareStatement(STMT_INSERT_ADDITIONAL_DETAILS);
			pst.setString(1, addotionalDetails.getJiraID());
			pst.setString(2, addotionalDetails.getAccountNumber());
			pst.setString(3, addotionalDetails.getCmsClientCode());
			pst.setString(4, addotionalDetails.getUrl());
			pst.setString(5, addotionalDetails.getIp());
			pst.setString(6, addotionalDetails.getPort());
			pst.setString(7, addotionalDetails.getChecksumRequired());
			pst.setString(8, addotionalDetails.getEncryptionRequired());
			pst.setString(9, str);
			pst.setString(10, addotionalDetails.getTypeOfWebservice());
			pst.setString(11, addotionalDetails.getCommunincationMethod());
			pst.setString(12, addotionalDetails.getUat());
			pst.setString(13, addotionalDetails.getDevelopement());
			pst.setString(14, addotionalDetails.getProduction());
			pst.setString(15, addotionalDetails.getModeOffered());
			pst.setString(16, addotionalDetails.getExpeTransPerDay());
			pst.setString(17, addotionalDetails.getTransLimitPerTran());
			pst.setString(18, addotionalDetails.getAmount());
			pst.setString(19, addotionalDetails.getAmountValidation());
			pst.setString(20, addotionalDetails.getUrn1());
			pst.setString(21, addotionalDetails.getUrn2());
			pst.setString(22, addotionalDetails.getDisclaimerText());
			pst.setString(23, addotionalDetails.getEmailRcptBill());
			pst.setString(24, addotionalDetails.getIfscCode());
			pst.setString(25, addotionalDetails.getVirtualCode());
			pst.setString(26, addotionalDetails.getIpsRefundCode());
			pst.setString(27, addotionalDetails.getCustCreditAccNumber());
			pst.setString(28, addotionalDetails.getHeaders());
			pst.setString(29, addotionalDetails.getReqResStructure());
			pst.setString(30, addotionalDetails.getTestingId());

			int i = pst.executeUpdate();
			if (i != 0) {
				isSaved = true;
			}
		} catch (NoSuchAlgorithmException | SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return isSaved;
	}

	public boolean updateFilePathDetails(String filePath, String Certificate, String jiraID){

		getDBConnection();
		PreparedStatement pst = null;
		boolean isSaved = false;
		try {
			pst = connection.prepareStatement(STMT_UPDATE_FILE_PATH);
			pst.setString(1, filePath);
			pst.setString(2, Certificate);
			pst.setString(3, jiraID);

			int i = pst.executeUpdate();
			if (i != 0) {
				isSaved = true;
			}
		} catch (Exception e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return isSaved;
	}
	public boolean updateFilePathDetailsAppathon(String filePath, String Certificate, String jiraID){
		getDBConnection();
		PreparedStatement pst = null;
		boolean isSaved = false;
		try {
			pst = connection.prepareStatement(STMT_UPDATE_FILE_PATH_APPATHON);
			pst.setString(1, filePath);
			pst.setString(2, Certificate);
			pst.setString(3, jiraID);

			int i = pst.executeUpdate();
			if (i != 0) {
				isSaved = true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return isSaved;
	}
	
	public boolean updatePDFFilePathDetails(String filePath, String Certificate, String jiraID){

		getDBConnection();
		PreparedStatement pst = null;
		boolean isSaved = false;
		try {
			pst = connection.prepareStatement(STMT_UPDATE_PDF_FILE_PATH);
			pst.setString(1, filePath);
			pst.setString(2, jiraID);

			int i = pst.executeUpdate();
			if (i != 0) {
				isSaved = true;
			}
		} catch (Exception e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return isSaved;
	}

	/* BAN213975-start */
	public List<Map<String, String>> getPortalTree(String id){
		getDBConnection();
		PreparedStatement prestmt = null;
		ResultSet rs = null;
		List<Map<String, String>> list = null;
		try {
			prestmt = connection.prepareStatement(STMT_SELECT_MENU);
			prestmt.setString(1, id);
			prestmt.setString(2, id);
			rs = prestmt.executeQuery();
			list = new ArrayList<>();
			Map map = null;
			while (rs.next()) {
				map = new HashMap<>();
				map.put("TREE_ID", rs.getString(1));
				map.put("TAB_NAME", rs.getString(2));
				map.put("TYPE", rs.getString(3));
				String Desc = rs.getString(4);
				if(Desc == null) {
					Desc = "";
				}
				map.put("DESCRIPTION", Desc);
				map.put("API_ID",rs.getString(5));
				list.add(map);
			}
			
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			try {
				prestmt.close();
				rs.close();
				if (connection != null) {
					DbUtil.close(connection);
				}
				
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			
			
		}
		return list;
	}

	public Map<String, String> getAdditionalParameters(String id) {
		getDBConnection();
		PreparedStatement prestmt = null;
		ResultSet rs = null;
		String ids[] = null;
		if(id.contains("\"")) {
			id=id.substring(1, id.lastIndexOf("\""));
		}
		if(id.contains(",")) {
			ids = id.split(",");	
		}
		
		String dynamicQuery = STMT_ADDITIONAL_PARAMETERS;
		if(ids == null || ids.length == 1) {
			dynamicQuery = dynamicQuery + "("+id+")";
		}
		else {
			dynamicQuery = dynamicQuery + "(";
			for(int i=0;i<ids.length;i++) {
				dynamicQuery = dynamicQuery + "'"+ids[i]+"',";
			}
			dynamicQuery = dynamicQuery.substring(0, dynamicQuery.lastIndexOf(","));
			dynamicQuery = dynamicQuery + ")";	
		}
		Map<String, String> map = null;
		try {
			prestmt = connection.prepareStatement(dynamicQuery);
			rs = prestmt.executeQuery();
			String API_NAME = "";
			String ADDITIONAL_DETAILS[] = null;
			String addDetail = "";
			while (rs.next()) {
				
				ADDITIONAL_DETAILS=rs.getString(2).trim().split(",");
				
				for(int i=0;i<ADDITIONAL_DETAILS.length;i++) {
					if(addDetail.length()==0) {
						addDetail = ADDITIONAL_DETAILS[i];
					}
					else if(!addDetail.contains(ADDITIONAL_DETAILS[i])) {
						addDetail = addDetail +","+ADDITIONAL_DETAILS[i];
					}
				}
				
				if(API_NAME.length() == 0) {
					API_NAME = rs.getString(3).trim();
				}
				else {
					API_NAME = API_NAME+", "+rs.getString(3).trim();
				}
			}
			
			map = new HashMap<>();
			map.put("ID", id);
			map.put("ADDITIONAL_DETAILS", addDetail);
			map.put("API_NAME", API_NAME);
			
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			try {
				prestmt.close();
				rs.close();
				if (connection != null) {
					DbUtil.close(connection);
				}
			}
			catch (Exception e) {
				// TODO: handle exception
			}
		}
		return map;
	}
	
	public Map temporary(String Key, String Value, String TREE_ID, String status, String position) {
		Map<String, String> temp = new LinkedHashMap<String, String>();
		temp.put(Key, Value);
		temp.put("TREE_ID", TREE_ID);
		temp.put("STATUS", status);
		temp.put("POSITION", position);

		return temp;
	}

	public Map temporary(String TREE_ID) {
		Map<String, String> temp = new LinkedHashMap<String, String>();

		temp.put("TREE_ID", TREE_ID);
		return temp;
	}
	
	@Override
	public List<String> getUserDetails(String username){
		getDBConnection();
		PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean isEnabled = false;
        List<String> usernames = null;
        int i = 0;
		try {
			preparedStatement = connection.prepareStatement("Select FIRST_NAME, EMAIL FROM PORTAL_USER_REG_TBL WHERE USER_NAME = ?");
            preparedStatement.setString(1, username);
            resultSet = preparedStatement.executeQuery();
        	usernames = new ArrayList<>();
            while (resultSet.next()) {
            	usernames.add(resultSet.getString("FIRST_NAME"));
            	usernames.add(resultSet.getString("EMAIL"));
            }
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
            if (resultSet != null) {
                try {
                    if (!resultSet.isClosed()) {
                        resultSet.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                    DbUtil.close(connection);
            }
        }
		return usernames;
	}
	
	public int isEmailDomainApproved(String domain){
		int isApproved = 1;// 0 = not Approved, 1 = Approved..
		getDBConnection();
		PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean isEnabled = false;
        List<String> usernames = null;
        int i = 0;
		try {
			preparedStatement = connection.prepareStatement("Select * from Company_CHECK where Domain_NM = ?");
            preparedStatement.setString(1, domain);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
            	isApproved = 0;
            }
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
            if (resultSet != null) {
                try {
                    if (!resultSet.isClosed()) {
                        resultSet.close();
                    }
                } catch (SQLException e) {
                	StringWriter ex = new StringWriter();
					e.printStackTrace(new PrintWriter(ex));
					LOGGER.error(ex.toString());
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                	StringWriter ex = new StringWriter();
					e.printStackTrace(new PrintWriter(ex));
					LOGGER.error(ex.toString());
                }
            }
            if (connection != null) {
                    DbUtil.close(connection);
            }
        }
		return isApproved;
	}
	
	public boolean saveAppathonDetails(String team_name, String team_captain_name, String team_captain_mobile, String team_captain_email, String team_size, String team_members_name, String team_members_mobile , String team_members_email, String location, String company_name, String username, String password, String usertype){
		getDBConnection();
		PreparedStatement pst = null;
		boolean isSaved = false;
		try {
			pst = connection.prepareStatement(STMT_INSERT_APPATHON_DETAILS);
			pst.setString(1, team_name);
			pst.setString(2, team_captain_name);
			pst.setString(3, team_captain_mobile);
			pst.setString(4, team_captain_email);
			pst.setString(5, team_size);
			pst.setString(6, team_members_name);
			pst.setString(7, team_members_mobile);
			pst.setString(8, team_members_email);
			pst.setString(9, location);
			pst.setString(10, company_name);
			pst.setString(11, username);
			pst.setString(12, password);
			pst.setString(13, usertype);

			int i = pst.executeUpdate();
			if (i != 0) {
				isSaved = true;
			}
			else {
				isSaved = false;
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return isSaved;
	}
	
	public Appathon_Details_Model fetchAppathonDetails(String username){
		getDBConnection();
		PreparedStatement pst = null;
		boolean isSaved = false;
		ResultSet rs = null;
		Appathon_Details_Model model = null;
		try {
			pst = connection.prepareStatement(QUERY_GET_APPATHON_DETAILS);
			pst.setString(1, username);
			rs = pst.executeQuery();
			
			while (rs.next()) {
				 model = new Appathon_Details_Model();
				 model.setUsername(rs.getString(1).trim());
				 /*model.setPassword(rs.getString(2).trim());*/				
				 model.setTeamName(rs.getString(3).trim());
				 model.setTeamSize(rs.getString(4).trim());
				 model.setTeamCaptainName(rs.getString(5).trim());
				 model.setTeamCaptainMobile(rs.getString(6).trim());
				 model.setTeamCaptainEmail(rs.getString(7).trim());
				 model.setTeamMembersName(rs.getString(8).trim());
				 model.setTeamMembersMobile(rs.getString(9).trim());
				 model.setTeamMembersEmail(rs.getString(10).trim());
				 model.setLocation(rs.getString(11).trim());
				 model.setCompanyName(rs.getString(12).trim());
				 /*model.setIdeaLink(rs.getString(14).trim());*/
				 model.setIdeaLink(rs.getString(13) == null ? "" : rs.getString(13).trim());
				 model.setFinalSubmissionLink(rs.getString(14) == null ? "" : rs.getString(14).trim());
				 model.setStatus(rs.getString(2) == null ? "" : rs.getString(2).trim());
				 model.setFinalURL(rs.getString(15) == null ? "" : rs.getString(15).trim());
                /*model.setFinalSubmissionLink(rs.getString(15).trim());*/
				 
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return model;
	}
	
	public Appathon_Details_Model fetchDetailsByEmail(String email){
		getDBConnection();
		PreparedStatement pst = null;
		boolean isSaved = false;
		ResultSet rs = null;
		Appathon_Details_Model model = null;
		try {
			pst = connection.prepareStatement(QUERY_GET_APPATHON_DETAILS);
			pst.setString(1, email);
			rs = pst.executeQuery();
			
			while (rs.next()) {
				 model = new Appathon_Details_Model();
				 model.setUsername(rs.getString(1).trim());
                /*model.setPassword(rs.getString(2).trim());*/
				 /*model.setUsertype(rs.getString(2).trim());*/
				 model.setTeamName(rs.getString(3).trim());
				 model.setTeamSize(rs.getString(4).trim());
				 model.setTeamCaptainName(rs.getString(5).trim());
				 model.setTeamCaptainMobile(rs.getString(6).trim());
				 model.setTeamCaptainEmail(rs.getString(7).trim());
				 model.setTeamMembersName(rs.getString(8).trim());
				 model.setTeamMembersMobile(rs.getString(9).trim());
				 model.setTeamMembersEmail(rs.getString(10).trim());
				 model.setLocation(rs.getString(11).trim());
				 model.setCompanyName(rs.getString(12).trim());
                 /*model.setIdeaLink(rs.getString(14).trim());*/
				 model.setIdeaLink(rs.getString(13) == null ? "" : rs.getString(13).trim());
				 model.setFinalSubmissionLink(rs.getString(14) == null ? "" : rs.getString(14).trim());
				 /*model.setFinalSubmissionLink(rs.getString(15).trim());*/
				 
			}
		} catch (Exception e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return model;
	}
	@Override
	public boolean updateAppathonDetails(
			String team_name, 
			String team_captain_name, 
			String team_captain_mobile,
			String team_captain_email, 
			String team_size, 
			String team_members_name, 
			String team_members_mobile,
			String team_members_email, 
			String location, 
			String company_name, 
			String username, 
			String idea_link, 
			String final_submission_link,
			String final_url) 
	{
		getDBConnection();
		PreparedStatement pst = null;
		boolean isSaved = false;
		try {
			
			pst = connection.prepareStatement(STMT_UPDATE_APPATHON_DETAILS);
			pst.setString(1, team_name);
			pst.setString(2, team_captain_name);
			pst.setString(3, team_captain_mobile);
			pst.setString(4, team_captain_email);
			pst.setString(5, team_size);
			pst.setString(6, team_members_name);
			pst.setString(7, team_members_mobile);
			pst.setString(8, team_members_email);
			pst.setString(9, location);
			pst.setString(10, company_name);
			pst.setString(11, username);
			pst.setString(12, idea_link);
			pst.setString(13, final_submission_link);
			pst.setString(14, final_url);
			pst.setString(15, username);
			
			int i = pst.executeUpdate();
			if (i != 0) {
				isSaved = true;
			}
			else {
				isSaved = false;
			}
		} catch (Exception e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return isSaved;
	
	}
	/* BAN213975-END */
/**BAN187248-Start**/
	@Override
	public List<String> getCompanyInfo(String name){
		getDBConnection();
		List <String> companyInfo =new  ArrayList<String>(); 
		PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean isEnabled = false;
        int count = 0;
		try {
			preparedStatement = connection.prepareStatement("select * from Company_Name where lower(Name) like lower('"+name+"%') order by ID asc");
            resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				if(count<100) {
					companyInfo.add(resultSet.getString("Name"));
					count++;
				}			
	           }
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
            if (resultSet != null) {
                try {
                    if (!resultSet.isClosed()) {
                        resultSet.close();
                        LOGGER.info("resultSet Closed");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                    LOGGER.info("preparedStatement Closed");
                } catch (SQLException e) {
                	StringWriter ex = new StringWriter();
					e.printStackTrace(new PrintWriter(ex));
					LOGGER.error(ex.toString());
                }
            }
            if (connection != null) {
                    DbUtil.close(connection);
                    LOGGER.info("DBConnection Closed");
            }
        }
		return companyInfo;
	}
	/**BAN187248-End**/
	
	public ArrayList<MenuTreeModel> getMenuDetails(String id){
		ArrayList<MenuTreeModel> mainList = null;
		Cache cache = CacheUtil.getMenuTreeDetailsCache();
		if (cache.isKeyInCache(CS_KEY_MENU_TREE_DTLS) && cache.get(CS_KEY_MENU_TREE_DTLS) != null) {
			Element ele = cache.get(CS_KEY_MENU_TREE_DTLS);
			mainList = (ArrayList<MenuTreeModel>) ele.getObjectValue();
			LOGGER.info("getMenuTreeDetails from Cache..");
		} else {
			LOGGER.info("getMenuTreeDetails from DB..");
			mainList = getMenuTreeDetails(id);
			cache.put(new Element(CS_KEY_MENU_TREE_DTLS, mainList));
		}
		
		return mainList;
	}
	
	
	public ArrayList<MenuTreeModel> getMenuTreeDetails(String id) {

		PreparedStatement prestmt = null;
		ResultSet rs = null;
		PreparedStatement prestmt1 = null;
		ResultSet rs1 = null;
		getDBConnection();
		Map<String, Map<String, String>> Data = new LinkedHashMap<String, Map<String, String>>();
		Map<String, String> ID = new LinkedHashMap<String, String>();
		MenuTreeModel model = null;
		ArrayList<MenuTreeModel> list = null;
		ArrayList<MenuTreeModel> mainList = new ArrayList<>();
		try {
			if (id.equals("0")) {
				prestmt1 = connection
						.prepareStatement("Select * from PORTAL_MENU_TREE Where PARENT_ID = ? order by POSITION asc");
				prestmt1.setString(1, id);
				rs1 = prestmt1.executeQuery();
				while (rs1.next()) {
					model = new MenuTreeModel();
					if (rs1.getInt("CHILD_COUNT") != 0) {

						model.setTAB_NAME(rs1.getString("TAB_NAME"));
						model.setTYPE(rs1.getString("TYPE"));
						model.setTREE_ID(rs1.getString("ID"));
						model.setPOSITION(rs1.getString("POSITION"));
						model.setSTATUS(rs1.getString("STATUS"));
						model.setCHILD_COUNT(rs1.getString("CHILD_COUNT"));
						model.setAPI_ID(rs1.getString("API_ID"));
						model.setLEVEL(rs1.getString("API_LEVEL"));

						ArrayList<MenuTreeModel> children = null;
						if (Integer.parseInt(rs1.getString("CHILD_COUNT").toString().trim()) > 0) {
							children = getChildNodes(rs1.getString("ID").toString().trim());
						}
						model.setChildren(children);
						mainList.add(model);
					} else {
						model.setTAB_NAME(rs1.getString("TAB_NAME"));
						model.setTYPE(rs1.getString("TYPE"));
						model.setTREE_ID(rs1.getString("ID"));
						model.setPOSITION(rs1.getString("POSITION"));
						model.setSTATUS(rs1.getString("STATUS"));
						model.setCHILD_COUNT(rs1.getString("CHILD_COUNT"));
						model.setAPI_ID(rs.getString("API_ID"));
						model.setLEVEL(rs.getString("API_LEVEL"));
						list.add(model);
					}
				}

			} else {
				prestmt = connection
						.prepareStatement("Select * from PORTAL_MENU_TREE Where ID = ? order by POSITION asc");
				prestmt.setString(1, id);
				rs = prestmt.executeQuery();

				while (rs.next()) {
					model = new MenuTreeModel();
					int child_count = rs.getInt("CHILD_COUNT");
					if (child_count == 0) {
						model.setTAB_NAME(rs.getString("TAB_NAME"));
						model.setTYPE(rs.getString("TYPE"));
						model.setTREE_ID(rs.getString("ID"));
						model.setPOSITION(rs.getString("POSITION"));
						model.setSTATUS(rs.getString("STATUS"));
						model.setCHILD_COUNT(rs.getString("CHILD_COUNT"));
						model.setAPI_ID(rs.getString("API_ID"));
						model.setLEVEL(rs.getString("API_LEVEL"));
					} else {

						model.setTAB_NAME(rs.getString("TAB_NAME"));
						model.setTYPE(rs.getString("TYPE"));
						model.setTREE_ID(rs.getString("ID"));
						model.setPOSITION(rs.getString("POSITION"));
						model.setSTATUS(rs.getString("STATUS"));
						model.setCHILD_COUNT(rs.getString("CHILD_COUNT"));
						model.setAPI_ID(rs.getString("API_ID"));
						model.setLEVEL(rs.getString("API_LEVEL"));
						list = getChildNodes(id);
						model.setChildren(list);
						mainList.add(model);
					}
				}

			}

		} catch (SQLException e) {
			ID.put("Error", e.toString());
			Data.put("Error", ID);
		} finally {
			if (prestmt1 != null) {
				try {
					rs1.close();
					prestmt1.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			if (prestmt != null) {
				try {
					rs.close();
					prestmt.close();
				} catch (SQLException e) {
					StringWriter ex = new StringWriter();
					e.printStackTrace(new PrintWriter(ex));
					LOGGER.error(ex.toString());
				}
				
			}
			if (connection != null) {
				DbUtil.close(connection);
				LOGGER.info("DBConnection Closed");
			}
		}

		return mainList;
	}
	
	public ArrayList<MenuDescriptionModel> getMenuDescription(String id){
		PreparedStatement prestmt = null;
		ResultSet rs = null;
		PreparedStatement prestmt1 = null;
		ResultSet rs1 = null;
		if(connection == null) {
			getDBConnection();
		}
		Map<String, Map<String, String>> Data = new LinkedHashMap<String, Map<String, String>>();
		Map<String, String> ID = new LinkedHashMap<String, String>();
		MenuDescriptionModel model = new MenuDescriptionModel();
		ArrayList<MenuDescriptionModel> list = null;
		ArrayList<MenuDescriptionModel> mainList = new ArrayList<>();
		try {
			if (!id.equals("0")) {
				prestmt = connection.prepareStatement("Select * from PORTAL_MENU_TREE Where ID = ? order by POSITION asc");
				prestmt.setString(1, id);
				rs = prestmt.executeQuery();

				while (rs.next()) {
					model.setTAB_NAME(rs.getString("TAB_NAME"));
					model.setTYPE(rs.getString("TYPE"));
					model.setID(rs.getString("ID"));
					model.setDESCRIPTION(rs.getString("DESCRIPTION"));
					if(rs.getString("IMAGE_URL") == null || rs.getString("IMAGE_URL")=="null")
					{
						model.setIMAGE_URL(" ");
					}
					else {
						model.setIMAGE_URL(rs.getString("IMAGE_URL"));
					}
					if(rs.getString("FILE_URL")==null || rs.getString("FILE_URL") == "null") {
						model.setFILE_URL(" ");
					}
					else {
						model.setFILE_URL(rs.getString("FILE_URL"));
					}
					
					ArrayList<MenuDescriptionModel> tabs = null;
					if(Integer.parseInt(rs.getString("CHILD_COUNT").toString().trim()) > 0) {
						tabs = getChildMenuDescription(rs.getString("ID").toString().trim());
					}
					model.setTabs(tabs);
					mainList.add(model);
				}
				
			}

			
		} catch (SQLException e) {
			ID.put("Error", e.toString());
			Data.put("Error", ID);
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} 
		finally {
			
			try {
				if (prestmt1 != null) {
					prestmt1.close();
					rs1.close();
				}
				if (prestmt != null) {
					rs.close();
					prestmt.close();
				}
				if (connection != null) {
					DbUtil.close(connection);
					LOGGER.info("DBConnection Closed");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mainList;
	}
	
	public ArrayList<MenuDescriptionModel> getChildMenuDescription(String id){
		
		PreparedStatement prestmt = null;
		ResultSet rs = null;

		PreparedStatement prestmt1 = null;
		if(connection == null) {
			getDBConnection();
		}
		
		Map<String, Map<String, String>> Data = new LinkedHashMap<String, Map<String, String>>();
		Map<String, String> ID = new LinkedHashMap<String, String>();
		MenuDescriptionModel model = null;
		ArrayList<MenuDescriptionModel> list = new ArrayList<>();
		try {
			prestmt1 = connection.prepareStatement("Select * from PORTAL_MENU_TREE Where PARENT_ID = ? order by POSITION asc");
			prestmt1.setString(1, id);
			rs = prestmt1.executeQuery();
			while(rs.next()) {
				model = new MenuDescriptionModel();
				model.setTAB_NAME(rs.getString("TAB_NAME"));
				model.setTYPE(rs.getString("TYPE"));
				model.setID(rs.getString("ID"));
				model.setDESCRIPTION(rs.getString("DESCRIPTION"));
				if(rs.getString("IMAGE_URL") == null || rs.getString("IMAGE_URL")=="null")
				{
					model.setIMAGE_URL(" ");
				}
				else {
					model.setIMAGE_URL(rs.getString("IMAGE_URL"));
				}
				if(rs.getString("FILE_URL")==null || rs.getString("FILE_URL") == "null") {
					model.setFILE_URL(" ");
				}
				else {
					model.setFILE_URL(rs.getString("FILE_URL"));
				}
				list.add(model);
			}
				
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		}
		
		finally {
			try {
				rs.close();
				prestmt1.close();
			} catch (SQLException e) {
				StringWriter ex = new StringWriter();
				e.printStackTrace(new PrintWriter(ex));
				LOGGER.error(ex.toString());
			}
		}
		return list;
	}

	public ArrayList<MenuTreeModel> getChildNodes(String id){
		
		ResultSet rs = null;

		PreparedStatement prestmt1 = null;
//		ResultSet rs1 = null;
		if(connection == null) {
			getDBConnection();
		}
		
		Map<String, Map<String, String>> Data = new LinkedHashMap<String, Map<String, String>>();
		Map<String, String> ID = new LinkedHashMap<String, String>();
		MenuTreeModel model = null;
		ArrayList<MenuTreeModel> list = new ArrayList<>();
		try {
			prestmt1 = connection.prepareStatement("Select * from PORTAL_MENU_TREE Where PARENT_ID = ? order by POSITION asc");
			prestmt1.setString(1, id);
			rs = prestmt1.executeQuery();
			
			while(rs.next()) {
				if (rs.getInt("CHILD_COUNT") != 0) {
					model = new MenuTreeModel();
					model.setTAB_NAME(rs.getString("TAB_NAME"));
					model.setTYPE(rs.getString("TYPE"));
					model.setTREE_ID(rs.getString("ID"));
					model.setPOSITION(rs.getString("POSITION"));
					model.setSTATUS(rs.getString("STATUS"));
					model.setCHILD_COUNT(rs.getString("CHILD_COUNT"));
					model.setAPI_ID(rs.getString("API_ID"));
					model.setLEVEL(rs.getString("API_LEVEL"));
					ArrayList<MenuTreeModel> children = null;
					if(Integer.parseInt(rs.getString("CHILD_COUNT").toString().trim()) > 0) {
						children = getChildNodes(rs.getString("ID").toString().trim());
					}
					model.setChildren(children);
					list.add(model);
				}
				else {
					model = new MenuTreeModel();
					model.setTAB_NAME(rs.getString("TAB_NAME"));
					model.setTYPE(rs.getString("TYPE"));
					model.setTREE_ID(rs.getString("ID"));
					model.setPOSITION(rs.getString("POSITION"));
					model.setSTATUS(rs.getString("STATUS"));
					model.setCHILD_COUNT(rs.getString("CHILD_COUNT"));
					model.setAPI_ID(rs.getString("API_ID"));
					model.setLEVEL(rs.getString("API_LEVEL"));
					list.add(model);
				}
				
			}
			prestmt1.close();
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		}
		
		finally {
			try {
				rs.close();
				prestmt1.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter ex = new StringWriter();
				e.printStackTrace(new PrintWriter(ex));
				LOGGER.error(ex.toString());
			}
			
//			if (connection != null) {
//				DbUtil.close(connection);
//				LOGGER.info("DBConnection Closed");
//			}
		}
		return list;
	}
	
	public Map getParentDetails(String Name, String type, String Tree_id, String Position, String status, String child_count) 
	{
	    Map <String, String>temp =new  LinkedHashMap<String, String>(); 
	    temp.put("TAB_NAME", Name);
	    temp.put("TYPE", type);
	    temp.put("TREE_ID", Tree_id);
	    temp.put("POSITION", Position);
	    temp.put("STATUS", status);
	    temp.put("CHILD_COUNT", child_count);
	    
	    
	    return temp;
	}
	
	public Map getAPI(String Name,String API_ID, String TREE_ID, String status,String position, String TYPE) 
	{
	    Map <String, String>temp =new  LinkedHashMap<String, String>(); 
	    temp.put("NAME", Name);
	    temp.put("API_ID", API_ID);
	    temp.put("TREE_ID", TREE_ID);
	    temp.put("TYPE",TYPE);
	    temp.put("STATUS", status);
	    temp.put("POSITION", position);

	    return temp;
	}
	
	public Map<String, ArrayList<String>> getPortalFAQ(){
		PreparedStatement prestmt = null;
		ResultSet rs = null;
		if(connection == null) {
			getDBConnection();
		}
		
		Map<String, ArrayList<String>> faq = new LinkedHashMap<String, ArrayList<String>>();
		try {
			prestmt = connection.prepareStatement("Select SRNO, HEADING, QUESTION, ANSWER from PORTAL_FAQ order by SRNO ASC");
			rs = prestmt.executeQuery();
			while(rs.next()) {
					
				ArrayList<String> list = new ArrayList<>();
				list.add(rs.getString(2).toString().trim());
				list.add(rs.getString(3).toString().trim());
				list.add(rs.getString(4).toString().trim());
				faq.put(rs.getString(1).toString().trim(), list);
			}
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		}
		
		finally {
			try {
				rs.close();
				prestmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				StringWriter ex = new StringWriter();
				e.printStackTrace(new PrintWriter(ex));
				LOGGER.error(ex.toString());
			}
			
			if (connection != null) {
				DbUtil.close(connection);
				LOGGER.info("DBConnection Closed");
			}
		}
		return faq;
	}
	
	public boolean saveJWTToken(String username, String token) {
		String isTokenExist = getJWTToken(username);
		getDBConnection();
		PreparedStatement pst = null;
		boolean isSaved = false;
		if(isTokenExist == null) {
			isSaved = false;
			try {
				DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh.mm aa");
		    	String dateString = dateFormat.format(new Date()).toString();
				pst = connection.prepareStatement(STMT_INSERT_JWT_TOKEN_DETAILS);
				pst.setString(1, username.toLowerCase());
				pst.setString(2, token);
				pst.setString(3, dateString);
				int i = pst.executeUpdate();
				if (i != 0) {
					isSaved = true;
				}
			} catch (SQLException e) {
				LOGGER.error(e);
			} finally {
				if (pst != null) {
					try {
						pst.close();
					} catch (SQLException e) {
						StringWriter ex = new StringWriter();
						e.printStackTrace(new PrintWriter(ex));
						LOGGER.error(ex.toString());
					}
				}
				if (connection != null) {
					DbUtil.close(connection);
				}
			}
		}
		else {
			isSaved = false;
			try {
				DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh.mm aa");
		    	String dateString = dateFormat.format(new Date()).toString();
				pst = connection.prepareStatement(STMT_UPDATE_JWT_TOKEN_DETAILS);
				pst.setString(1, token);
				pst.setString(2, dateString);
				pst.setString(3, username.toLowerCase());
				int i = pst.executeUpdate();
				if (i != 0) {
					isSaved = true;
				}
			} catch (SQLException e) {
				StringWriter ex = new StringWriter();
				e.printStackTrace(new PrintWriter(ex));
				LOGGER.error(ex.toString());
			} finally {
				if (pst != null) {
					try {
						pst.close();
					} catch (SQLException e) {
						StringWriter ex = new StringWriter();
						e.printStackTrace(new PrintWriter(ex));
						LOGGER.error(ex.toString());
					}
				}
				if (connection != null) {
					DbUtil.close(connection);
				}
			}
		}
		
		return isSaved;
	}
	
	public String getJWTToken(String username) {
		String JWTToken = null;
		getDBConnection();
		ResultSet rs = null;
		PreparedStatement pst = null;
		try {
			pst = connection.prepareStatement(STMT_GET_JWT_TOKEN);
			pst.setString(1, username.toLowerCase());
			
			rs = pst.executeQuery();
			while(rs.next()) {
				JWTToken = rs.getString(1).trim();
			}
		} catch (SQLException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		} finally {
			if (pst != null) {
				try {
					pst.close();
					rs.close();
				} catch (SQLException e) {
					StringWriter ex = new StringWriter();
					e.printStackTrace(new PrintWriter(ex));
					LOGGER.error(ex.toString());
				}
			}
			if (connection != null) {
				DbUtil.close(connection);
			}
		}
		return JWTToken;
	}
}
