package com.icici.apigw.db;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.commons.dbcp2.Utils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.icici.apigw.common.PortalException;
import com.icici.apigw.controller.RestApi;
import com.icici.apigw.util.GwConstants;

public class DbUtil {
	private static final Logger LOGGER = LogManager.getLogger(DbUtil.class);
	private static BasicDataSource lrsDs;
	private static BasicDataSource docDs;
	
	public static Connection getLrsConnection(){
		try {
			if (lrsDs == null) {
				lrsDs = new BasicDataSource();
				lrsDs.setDriverClassName(GwConstants.DB_LRS_DRIVER);
				lrsDs.setUrl(GwConstants.DB_LRS_URL);
				lrsDs.setUsername(GwConstants.DB_LRS_USERNAME);
				lrsDs.setPassword(GwConstants.DB_LRS_PASSWORD);
				
				lrsDs.setMinIdle(GwConstants.DB_LRS_MIN_IDLE);
				lrsDs.setMaxIdle(GwConstants.DB_LRS_MAX_IDLE);
				lrsDs.setMaxWaitMillis(GwConstants.DB_LRS_MAX_WAIT_MILLIS);
			}
			return lrsDs.getConnection();
		} catch (SQLException e) {
			try {
				throw new PortalException("Exception occured while creating new datasource", e);
			} catch (PortalException e1) {
				// TODO Auto-generated catch block
				StringWriter ex = new StringWriter();
				e.printStackTrace(new PrintWriter(ex));
				LOGGER.error(ex.toString());
			}
		}
		return null;
	}
	
	public static Connection getDocConnection() throws PortalException {
		try {
			if (docDs == null) {
				docDs = new BasicDataSource();
				docDs.setDriverClassName(GwConstants.DB_DOC_DRIVER);
				docDs.setUrl(GwConstants.DB_DOC_URL);
				docDs.setUsername(GwConstants.DB_DOC_USERNAME);
				docDs.setPassword(GwConstants.DB_DOC_PASSWORD);
				
				docDs.setMinIdle(GwConstants.DB_DOC_MIN_IDLE);
				docDs.setMaxIdle(GwConstants.DB_DOC_MAX_IDLE);
				docDs.setMaxWaitMillis(GwConstants.DB_DOC_MAX_WAIT_MILLIS);
			}
			return docDs.getConnection();
		} catch (SQLException e) {
			throw new PortalException("Exception occured while creating new datasource", e);
		}
	}
	
	public static void close(Connection connJCG){
		Utils.closeQuietly(connJCG);
	}

}
