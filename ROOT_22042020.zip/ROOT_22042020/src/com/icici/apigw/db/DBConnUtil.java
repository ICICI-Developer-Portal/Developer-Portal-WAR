package com.icici.apigw.db;

import java.io.PrintWriter;
import java.io.StringWriter;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.icici.apigw.dao.ApiDataDaoImpl;

public class DBConnUtil {
	private static DataSource dataSource;
	private static final String JNDI_LOOKUP_SERVICE = "java:/comp/env/jdbc/devPortal";
	private static final Logger LOGGER = LogManager.getLogger(DBConnUtil.class);
	static {
		try {
			Context context = new InitialContext();
			Object lookup = context.lookup(JNDI_LOOKUP_SERVICE);
			if(lookup != null) {
				dataSource = (DataSource) lookup;
			}
			else {
				new RuntimeException("Datasource not found !!!");
			}
		}
		catch (NamingException e) {
			StringWriter ex = new StringWriter();
			e.printStackTrace(new PrintWriter(ex));
			LOGGER.error(ex.toString());
		}
	}
	
	public static DataSource getDataSoure() {
		return dataSource;
	}
}

